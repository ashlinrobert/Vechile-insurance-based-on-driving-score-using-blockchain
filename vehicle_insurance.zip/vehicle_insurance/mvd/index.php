<?php
include('header.php');
?>
	
 	
	
    <div id="slide-wrap">
		<!--<img src="/themes/mvd/images/slider_img.jpg">-->
							  <div>
    <div class="views-element-container" id="block-views-block-slideshow-block-1">
  
    
      <div><div class="js-view-dom-id-a0df8c162864a77041bc1153e2fbf02be8c535f5a6aefd87e2dccfaf9a230681">
  
  
  

  
  
  

    <div class="skin-default">
    
    <div id="views_slideshow_cycle_main_slideshow-block_1" class="views_slideshow_cycle_main views_slideshow_main">
    <div id="views_slideshow_cycle_teaser_section_slideshow-block_1"  class="views_slideshow_cycle_teaser_section">
     <div id="views_slideshow_cycle_div_slideshow-block_1_0"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-1 views-row-odd">
      <div  class="views-row views-row-0 views-row-odd views-row-first">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://play.google.com/store/apps/details?id=com.nic.mparivahan&amp;pli=1" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/nextgen-en.jpg" width="1920" height="450" alt="mParivahan app" typeof="Image" />

</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_slideshow-block_1_1"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-2 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-1 views-row-even">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://mvd.kerala.gov.in/ml/vidyavahan-app" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/vidyavahini-app_1.jpg" width="1920" height="450" alt="Vidyavahan App" typeof="Image" />

</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_slideshow-block_1_2"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-3 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-2 views-row-odd">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://mvd.kerala.gov.in/index.php/index.php/en/fine-remittance" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/mvd-fine.jpg" width="1920" height="450" alt="MVD fine-remittance" typeof="Image" />

</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_slideshow-block_1_3"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-4 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-3 views-row-even">
  <div class="views-field views-field-field-cc-link"><div class="field-content">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/banner_1.jpg" width="1920" height="450" alt="MVD pilots the Oxygen Move" typeof="Image" />

</div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_slideshow-block_1_4"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-5 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-4 views-row-odd views-row-last">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://vahan.parivahan.gov.in/fancy/faces/public/login.xhtml" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/fancy-choice-en.jpg" width="1920" height="450" alt="Fancy Number" typeof="Image" />

</a></div></div>
</div>

  </div>

  </div>

</div>


          <div class="views-slideshow-controls-bottom clearfix">
        
<ul class="widget_pager widget_pager_bottom views-slideshow-pager-bullets views_slideshow_pager_field" id="widget_pager_bottom_slideshow-block_1"><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_0">0</li><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_1">1</li><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_2">2</li><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_3">3</li><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_4">4</li></ul>

      </div>
        </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
							
	</div>	
</div>

<div id="latestnews-wrap"> 

		<div id="news1" class="container row clr">
			
			<span class = "content">
								  <div>
    <div class="views-element-container" id="block-views-block-news-ticker-block-1">
  
    
      <div><div class="js-view-dom-id-3ab4e2572c7a73374477f7fab8f45306cfc9e3d65aebe7a207a2b93f9fdfac11">
  
  
  

      <header>
      <div class="heading">Latest News :</div>
    </header>
  
  
  

    <div class="skin-default">
    
    <div id="views_slideshow_cycle_main_news_ticker-block_1" class="views_slideshow_cycle_main views_slideshow_main">
    <div id="views_slideshow_cycle_teaser_section_news_ticker-block_1"  class="views_slideshow_cycle_teaser_section">
     <div id="views_slideshow_cycle_div_news_ticker-block_1_0"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-1 views-row-odd">
      <div  class="views-row views-row-0 views-row-odd views-row-first">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1703" hreflang="ml">Press release regarding Driving license.</a></span></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_news_ticker-block_1_1"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-2 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-1 views-row-even">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1702" hreflang="ml">E-SUBSIDY FOR ELECTRIC AUTO RICKSHAW - SANCTIONED FOR THE PERIOD FROM 24/01/2023 TO 31/03/2023</a></span></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_news_ticker-block_1_2"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-3 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-2 views-row-odd">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1693" hreflang="ml">REGIONAL TRANSPORT AUTHORITY, KANNUR DECISION OF RTA Dtd. 07.03.2023</a></span></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_news_ticker-block_1_3"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-4 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-3 views-row-even">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1692" hreflang="ml">REGIONAL TRANSPORT AUTHORITY, VATAKARA AGENDA FOR THE RTA MEETING TO BE HELD ON 11.04.2023</a></span></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_news_ticker-block_1_4"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-5 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-4 views-row-odd views-row-last">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1691" hreflang="ml">DECISION OF THE MEETING OF REGIONAL TRANSPORT AUTHORITY ERNAKULAM HELD ON 23-01-2023</a></span></div>
</div>

  </div>

  </div>

</div>


        </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
							</span>
		</div>
	</div>


<div class = "leaders">
	<div class="row container ">
						  <div>
    <div id="block-leaders">
  
    
      
            <div><div class="column4 first">
<div class="card"><img alt="Chief minister" data-entity-type="file" data-entity-uuid="f818dc67-57e5-4cca-b4cd-2acb26f38cd9" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/cm.jpg" /><div class="container centered">
<h1 class="team-name">Shri Pinarayi Vijayan</h1>

<p class="title">Hon'ble Chief Minister, Kerala</p>
</div>
</div>
</div>

<div class="column4">
<div class="card"><img alt="Transport Minister" data-entity-type="file" data-entity-uuid="a7d3ba31-ff81-46ab-a0ad-73c7f3d6a15f" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/tm-new.jpg" /><div class="container centered">
<h1>Shri Antony Raju</h1>

<p class="title">Hon'ble Minister for Transport, Kerala</p>
</div>
</div>
</div>

<div class="column4">
<div class="card"><img alt="Transport Commissioner" data-entity-type="file" data-entity-uuid="43999052-7bcf-4012-904f-8f55d67032b7" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/tcnew1_2.jpg" /><div class="container centered">
<h1>Shri S Sreejith, IPS, ADGP</h1>

<p class="title">Transport Commissioner</p>
</div>
</div>
</div>

<div class="column4 last">
<div class="card"><img alt="Additional Transport Commissioner" data-entity-type="file" data-entity-uuid="ec54a526-bd7d-489a-9c3f-cf2e0456a5ec" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/atc-new_0.jpg" /><div class="container centered">
<h1>Shri Pramoj Sanker P S , IOFS</h1>

<p class="title">Additional Transport Commissioner</p>
</div>
</div>
</div>
</div>
      
  </div>
<div id="block-homemainicons">
  
    
      
            <div><div id="user1-wrap">
<div class="container row clr" id="user1">
<main><section class="cards"><article class="icons firstOne"><div class="imght"><a href="https://mvd.kerala.gov.in/en/citizenCorner"><img alt="Citizen Corner" data-entity-type="file" data-entity-uuid="eb45a61b-8196-49ba-9a3c-bcd85c807dee" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/citizen_corner.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/citizenCorner">Citizen Corner</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/employeeCorner"><img alt="Employees Corner" data-entity-type="file" data-entity-uuid="5bd56ebb-60c6-4f56-ad87-93ffd5996ec3" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/emply_corner.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/employeeCorner">Employees Corner</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/faqs"><img alt="FAQ" data-entity-type="file" data-entity-uuid="63ebdba7-06cc-4714-b882-e2b0b82ff24f" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/faq.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/faqs">How Do I / FAQ</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/downloads"><img alt="Downloads" data-entity-type="file" data-entity-uuid="0040246f-7e8b-4d32-a7cf-14cfec74ad74" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/downloads.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/downloads">Downloads</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/roadSafety"><img alt="Road Safety Rules" data-entity-type="file" data-entity-uuid="bfae3c00-19c2-4b09-9f6b-afad95462323" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/road_safty.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/roadSafety">Road Safety Rules</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/news"><img alt="Latest News" data-entity-type="file" data-entity-uuid="f96223f7-d0e0-4c96-9e4e-d0d6ad6d334b" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/news.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/news">Latest News</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/rta-sta"><img alt="Latest News" data-entity-type="file" data-entity-uuid="f96223f7-d0e0-4c96-9e4e-d0d6ad6d334b" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/news.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/rta-sta">RTA/STA Agenda</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/tax-0"><img alt="Tax" data-entity-type="file" data-entity-uuid="e19352ba-f1fb-4dcd-970a-fc3fe939fd0c" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/tax.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/tax-0">Tax</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/cess-0"><img alt="Cess" data-entity-type="file" data-entity-uuid="a9464358-d6c4-46d9-88b1-7a8342e37978" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/cess.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/cess-0">Cess</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/fees-0"><img alt="Fees" data-entity-type="file" data-entity-uuid="9cc6d1fe-16b7-4305-af10-bf0ca1d57834" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/fee.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/fees-0">Fees</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/sop-services"><img alt="SOP for Services" data-entity-type="file" data-entity-uuid="9e91923b-2f97-46d1-8b5b-d03adbc44ca3" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/sophome.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/sop-services">SOP For Services</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/idtr"><img alt="Institute of Driver Training and Research" data-entity-type="file" data-entity-uuid="29371c95-c3f2-4d7f-86ca-6704e531e62c" height="69" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/idtr.png" width="129" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/idtr">IDTR</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/en/bus-route-timing"><img alt="RMS(Bus timing)" data-entity-type="file" data-entity-uuid="4929ad91-a30d-401d-a3d5-f91c1fa65ae4" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/bus.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/en/bus-route-timing">RMS (Bus timing)</a></h2>
</article><article class="icons"><div class="imght"><a href="https://mvd.kerala.gov.in/ml/vidyavahan-app"><img alt="vidyavahan-app" data-entity-type="file" data-entity-uuid="c7de26e4-ab19-4113-915d-836a82905218" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/vidyavahan-icon_0.png" /></a></div>

<h2><a href="https://mvd.kerala.gov.in/ml/vidyavahan-app">Vidyavahan App</a></h2>
</article></section></main></div>
</div>
</div>
      
  </div>

  </div>

					
	</div> 
</div>


<div id="user1-wrap">
	
</div>



<div id="wrapper"> 
	
	<div class="container row clr"></div>
	<!--<div id="news1-wrap">
		<div id="news1" class="container row clr">  			
  			<div class="imageHolder">
    		
								
			</div>
			<div class="section2 group">
									
			</div>						
		</div>
	</div> -->
	
	
	<div id="news1-wrap">
		<div id="news1" class="container row clr">
					</div>
	</div>

	<!--<div id="news1-wrap" style="background: #FFFFFF;">
				  <div>
    <div id="block-homefootericons">
  
    
      
            <div><div class="section4 group">
<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://www.india.gov.in/" target="_blank"><img alt="India Government" data-entity-type="file" data-entity-uuid="75d4eb80-8a98-47bc-b925-c62384162f56" src="/sites/default/files/inline-images/1.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://kerala.gov.in/" target="_blank"><img alt="Kerala Government" data-entity-type="file" data-entity-uuid="d8d3ff6e-7156-44e7-befa-9dc153004926" src="/sites/default/files/inline-images/2.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://www.keralacm.gov.in/" target="_blank"><img alt="Kerala CM" data-entity-type="file" data-entity-uuid="228dd30d-fea0-40d9-8243-a0a540eef803" src="/sites/default/files/inline-images/3.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://roadsafety.kerala.gov.in/" target="_blank"><img alt="Road Safety Kerala" data-entity-type="file" data-entity-uuid="632b4e35-95d4-4ad7-b787-e5fc488c354c" src="/sites/default/files/inline-images/4.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://parivahan.gov.in/parivahan/" target="_blank"><img alt="Parivahan Sewa" data-entity-type="file" data-entity-uuid="f42a7f7a-2d0e-4fb6-a498-dc0db9bb862e" src="/sites/default/files/inline-images/5.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://www.natpac.kerala.gov.in/" target="_blank"><img alt="NATPAC" data-entity-type="file" data-entity-uuid="4554f282-fba2-4b5a-9c68-dff19d9038b9" src="/sites/default/files/inline-images/6.png" /></a></div>
</div>
</div>
</div>
      
  </div>

  </div>
    
			</div> -->
	                                                            
	<!--<div id="box-wrap" class="container row clr">	</div>-->

	<div id="news1-wrap">
		<div id="news1" class="container row clr connect">									
			<div class="section2 group">
				<div class="coloumn2 span_1_of_2">
					<div class="childbox">
						<h1></h1>
						<div style="background: #FFF; padding: 3px; height: auto;">														
														  <div>
    <div class="views-element-container" id="block-views-block-block-slider-block-1">
  
      <h2>Updates</h2>
    
      <div><div class="js-view-dom-id-b8a5f341f5f7ad07bf5fd8d1e84433018275413ed4ad183a0aa76e2c48dbe72f">
  
  
  

  
  
  

    <div class="skin-default">
    
    <div id="views_slideshow_cycle_main_block_slider-block_1" class="views_slideshow_cycle_main views_slideshow_main">
    <div id="views_slideshow_cycle_teaser_section_block_slider-block_1"  class="views_slideshow_cycle_teaser_section">
     <div id="views_slideshow_cycle_div_block_slider-block_1_0"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-1 views-row-odd">
      <div  class="views-row views-row-0 views-row-odd views-row-first">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://sarathi.parivahan.gov.in/SarathiReport/sarathiHomePublic.do" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/styles/frontbanner2/public/2021-09/SARATHI-DASHBOARD_0.jpg?itok=ClHfKr1k" width="575" height="260" alt="Sarathi Dashboard" typeof="Image" />


</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_block_slider-block_1_1"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-2 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-1 views-row-even">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://vahan.parivahan.gov.in/vahan4dashboard/" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/styles/frontbanner2/public/2021-09/vahan-dashboard.jpg?itok=1XXUkWPH" width="575" height="260" alt="Vahan Dashboard" typeof="Image" />


</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_block_slider-block_1_2"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-3 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-2 views-row-odd">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://mvd.kerala.gov.in/sites/default/files/2019-03/fancy.pdf" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/styles/frontbanner2/public/2019-03/vahan_0.jpg?itok=pakkLHHA" width="575" height="260" alt="Vahan" typeof="Image" />


</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_block_slider-block_1_3"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-4 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-3 views-row-even views-row-last">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://mvd.kerala.gov.in/index.php/index.php/en/revision-of-auto-taxi-hire-charges" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/styles/frontbanner2/public/2019-02/1.jpg?itok=f-21pxcc" width="575" height="260" alt="Revision of hire rate of auto rickshaw" typeof="Image" />


</a></div></div>
</div>

  </div>

  </div>

</div>


          <div class="views-slideshow-controls-bottom clearfix">
        
<ul class="widget_pager widget_pager_bottom views-slideshow-pager-bullets views_slideshow_pager_field" id="widget_pager_bottom_block_slider-block_1"><li id="views_slideshow_pager_field_item_bottom_block_slider-block_1_0">0</li><li id="views_slideshow_pager_field_item_bottom_block_slider-block_1_1">1</li><li id="views_slideshow_pager_field_item_bottom_block_slider-block_1_2">2</li><li id="views_slideshow_pager_field_item_bottom_block_slider-block_1_3">3</li></ul>

      </div>
        </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
								
						</div>
					</div>
				</div>		
			
				<div class="coloumn2 span_1_of_2">
					<div class="childbox">
						<div class="imageHolder">
							<h1></h1>
							<div style="background: #fff; padding:0 20px 20px 20px;">								
																  <div>
    <div class="views-element-container" id="block-views-block-google-map-block-1-2">
  
      <h2>Locate us</h2>
    
      <div><div class="js-view-dom-id-3938092e3a2461cc93df022cbd46f94f11cd8f79d4caf7a2fab333f229cd6bf8">
  
  
  

  
  
  

      <div class="views-row"><div class="views-field views-field-field-gmap"><div class="field-content">  <iframe width="100%" height="236px" frameborder="0" style="border:0" src="https://maps.google.com/maps?hl=en&amp;q=Transport+Commissinarate+thycaus+trivandrum&amp;t=m&amp;z=14&amp;output=embed"></iframe>
  <p class="simple-gmap-link"><a href="https://maps.google.com/maps?q=Transport+Commissinarate+thycaus+trivandrum&amp;hl=en&amp;t=m&amp;z=14" target="_blank">View larger map</a></p>
</div></div></div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
														
							</div>
						</div>						
					</div>
				</div>		
			</div>					  			
		</div>
	</div>
</div>


<div id="user-wrap" class = "logo-wrap">
	<div id="user2" class="container row clr">
	
		  <div>
    <div id="block-homefootericons">
  
    
      
            <div><div class="section4 group">
<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://www.india.gov.in/" target="_blank"><img alt="India Government" data-entity-type="file" data-entity-uuid="75d4eb80-8a98-47bc-b925-c62384162f56" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/1.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://kerala.gov.in/" target="_blank"><img alt="Kerala Government" data-entity-type="file" data-entity-uuid="d8d3ff6e-7156-44e7-befa-9dc153004926" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/2.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://www.keralacm.gov.in/" target="_blank"><img alt="Kerala CM" data-entity-type="file" data-entity-uuid="228dd30d-fea0-40d9-8243-a0a540eef803" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/3.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://roadsafety.kerala.gov.in/" target="_blank"><img alt="Road Safety Kerala" data-entity-type="file" data-entity-uuid="632b4e35-95d4-4ad7-b787-e5fc488c354c" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/4.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://parivahan.gov.in/parivahan/" target="_blank"><img alt="Parivahan Sewa" data-entity-type="file" data-entity-uuid="f42a7f7a-2d0e-4fb6-a498-dc0db9bb862e" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/5.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://www.natpac.kerala.gov.in/" target="_blank"><img alt="NATPAC" data-entity-type="file" data-entity-uuid="4554f282-fba2-4b5a-9c68-dff19d9038b9" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/6.png" /></a></div>
</div>
</div>
</div>
      
  </div>

  </div>
    
			            
	</div>
</div>


<div id="user2-wrap" class = "footer-wrap">
	<div id="user2" class="container row clr">
		<div class="section4 group">
			
			<div class="coloumn4 span_1_of_3 block block1">
				<div class="childbox box">
					
										  <div>
    <div class="views-element-container" id="block-views-block-video-gallery-block-1">
  
    
      <div><div class="js-view-dom-id-88a7a707c7a43c679ea99df95c73085ca8df9006411a7ba38c4a2a004e6d6e42">
  
  
  

  
  
  

  <ul data-blazy="" class="blazy blazy--view blazy--view--video-gallery blazy--view--video-gallery--block-1 blazy--grid block-column block-count-1 small-block-column-1 medium-block-column-1 large-block-column-1" id="blazy-views-video-gallery-block-1-1"><li class="grid"><div class="grid__content"><div class="views-field views-field-body"><div class="field-content"><p><iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen="" frameborder="0" height="215" src="https://www.youtube.com/embed/p9gLMdPYELs" title="YouTube video player" width="360"></iframe></p>
</div></div><div class="views-field views-field-nothing"><strong class="field-content"><a href="https://www.youtube.com/channel/UCguF4r6jOGqO2-OVrEDaplw/videos" target="_blank"><strong>more videos</strong></a></strong></div></div>
</li></ul>
    

  
  

  
  
</div>
</div>

  </div>
<div id="block-footeraboutusblock">
  
      <h2>About us</h2>
    
      
            <div><p style="text-align:left;">The Motor Vehicles Department is regulated by the Government of Kerala in terms of policy formulation and its implementation.  The Department is administered by the Transport Commissioner who is the Head of Department.</p>

<h4><strong>Connect us</strong></h4>

<div class="social"><a href="https://m.facebook.com/mvd.socialmedia/" id="" rel="" target="_blank" title=""><img alt="Facebook" data-entity-type="file" data-entity-uuid="df4faea8-b070-49e1-bf83-b428b90e006b" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-facebook-48.png" class="align-left" /></a></div>

<div class="social"><a href="https://twitter.com/KeralaMvd" id="" rel="" target="_blank" title=""><img alt="Twitter" data-entity-type="file" data-entity-uuid="5826b440-f9a2-4246-add0-47c7bbd076aa" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-twitter-48.png" class="align-left" /></a></div>

<div class="social"><a href="https://www.youtube.com/channel/UCguF4r6jOGqO2-OVrEDaplw/videos" id="" rel="" target="_blank" title=""><img alt="Youtube" data-entity-type="file" data-entity-uuid="f555c39c-3367-414a-911f-35ff85e71fb8" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-youtube-squared-48.png" class="align-left" /></a></div>

<div class="social"><a href="https://instagram.com/mvd_kerala?igshid=h5korves8y26" id="" rel="" target="_blank" title=""><img alt="Instagram" data-entity-type="file" data-entity-uuid="696e2ba9-16fc-4404-b5f9-34c777b252f3" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/instagram_0.png" class="align-left" /></a></div>

<p> </p>

<h4><br /><a href="http://old.mvd.kerala.gov.in/" style="color:#ffcc00!important;" target="_blank" title="old.mvd.kerala.gov.in">Visit Old Website</a></h4>
</div>
      
  </div>

  </div>
    
						
				</div>
			</div>
		
		
			<div class="coloumn4 span_1_of_3 block block2">
				<div class="childbox box">
										  <div>
    <div class="views-element-container" id="block-views-block-footer-contact-block-1">
  
    
      <div><div class="js-view-dom-id-87290f60699ddcee9030658a7a2cc2a1246e7865f1b60bdb5aa52ff0d1407ac3">
  
  
  

  
  
  

      <div class="views-view-grid horizontal cols-1 clearfix">
            <div class="views-row clearfix row-1">
                  <div class="views-col col-1" style="width: 100%;"><div class="views-field views-field-body"><div class="field-content"><ul><li>
	<p style="text-align:left;"><strong>Helpdesk </strong>Online Services<br />
	0471-2328799 (10:15 AM - 05:00 PM)<br />
	(Lunch break 01:15 P.M - 2:00 P.M)<br />
	email: ssgcell[dot]mvd[at]kerala[dot]gov[dot]in</p>
	</li>
	<li>
	<p style="text-align:left;"><strong>General Enquiry </strong>(Public Relation Officer):<br />
	(10:15 AM - 05:00 PM) (Lunch break 01:15 P.M - 2:00 P.M)<br />
	Transport Commissionerate: 0471-2333317<br />
	e-mail: tcoffice[dot]mvd[at]kerala[dot]gov[dot]in</p>
	</li>
	<li>
	<p style="text-align:left;"><strong>RTO / JRTO Contact Numbers</strong><br /><br /><a href="https://mvd.kerala.gov.in/directory" style="color:#ffcc00!important;" title="https://mvd.kerala.gov.in/directory">https://mvd.kerala.gov.in/directory</a></p>
	</li>
	<li>
	<p style="text-align:left;"><strong>Grievance</strong></p>
	</li>
	<li>
	<p style="text-align:left;">91 88 96 11 00 (10:15 AM - 05:00 PM)<br />
	(Lunch break 01:15 P.M - 2:00 P.M)<br />
	email: complaints[dot]mvd[at]kerala[dot]gov[dot]in</p>
	</li>
</ul></div></div></div>
              </div>
      </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
						
				</div>
			</div>	
			
			<div class="coloumn4 span_1_of_3 block3">
				<div class="childbox">
										  <div>
    <div class="views-element-container" id="block-views-block-footer-contact-block-2">
  
    
      <div><div class="js-view-dom-id-13d928f1d88a6b94d7a3e9c24f5efe5d62273b6735cc1d59cb4f1f7a3612cc10">
  
  
  

  
  
  

      <div class="views-view-grid horizontal cols-1 clearfix">
            <div class="views-row clearfix row-1">
                  <div class="views-col col-1" style="width: 100%;"><div class="views-field views-field-body"><div class="field-content"><ul><li style="list-style:none;">
	<p><strong>Helpdesk:</strong></p>

	<p style="text-align:left;"><strong>Vahan : </strong>Vehicle Registration/Fitness/Tax/Permit/Fancy, Dealer<br />
	helpdesk-vahan[at]gov[dot]in,<br />
	+91-120-2459168    6:00 AM-10:00 PM</p>

	<p style="text-align:left;"><strong>Sarathi : </strong>Licence<br />
	helpdesk-sarathi[at]gov[dot]in<br />
	+91-120-2459169    6:00 AM-10:00 PM</p>

	<p style="text-align:left;">eChallan<br />
	helpdesk-echallan[at]gov[dot]in<br />
	+91-120-2459171    6:00 AM-10:00 PM</p>

	<p style="text-align:left;">mParivahan<br />
	helpdesk-mparivahan[at]gov[dot]in<br />
	+91-120-2459171    6:00 AM-10:00 PM</p>

	<div style="background:#313131; padding:10px 0 10px 10px;">
	<p style="text-align:left;"><strong>Kerala Government Call Center</strong></p>

	<p style="text-align:left;">  BSNL  - 155300 , 0471 2335523       </p>
	</div>
	<br /><strong>For more details: <a href="https://mvd.kerala.gov.in/directory" style="color:#ffcc00!important;" target="_blank">Click here</a></strong></li>
</ul></div></div></div>
              </div>
      </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
						
				</div>
			</div>	
				
		</div>	            
	</div>
</div>

<!-- FOOTER START  --> 
<div id="footer-wrap" >
  <div id="footer" class="container row clr">
    <div id="footer-nav">  
      	    <div>
    <nav role="navigation" aria-labelledby="block-aboutportal-2-menu" id="block-aboutportal-2">
            
  <h2 class="visually-hidden" id="block-aboutportal-2-menu">About Portal</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/screen-reader-access" title="Screen Reader Access">Screen Reader Access</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/disclaimer" data-drupal-link-system-path="node/80">Disclaimer</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/copy-right-policy" data-drupal-link-system-path="node/81">Copy Right Policy</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/privacy-policy" data-drupal-link-system-path="node/82">Privacy Policy</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/webLinks" data-drupal-link-system-path="webLinks">Weblinks</a>
              </li>
        </ul>
  


  </nav>

  </div>
    
	  	
    </div>
	<div id="footer-text">
	  <div class = "copyrig" style="display: inline-block;">Motor Vehicles Department Copyright &copy; 2023. All Rights Reserved. </div>
	  <div class = "credit" >Designed and Maintained by <a href="http://www.cdit.org/" target="_blank">C-Dit</a></div>
	</div> 
  </div>
</div>
 







  </div>

    
    <script type="application/json" data-drupal-selector="drupal-settings-json">{"path":{"baseUrl":"\/","scriptPath":null,"pathPrefix":"en\/","currentPath":"node","currentPathIsAdmin":false,"isFront":true,"currentLanguage":"en"},"pluralDelimiter":"\u0003","suppressDeprecationErrors":true,"ajaxPageState":{"libraries":"blazy\/column,blazy\/grid,blazy\/load,blazy\/ratio,core\/html5shiv,mvd\/framework,search_api_autocomplete\/search_api_autocomplete,superfish\/superfish,superfish\/superfish_hoverintent,superfish\/superfish_smallscreen,superfish\/superfish_supersubs,superfish\/superfish_supposition,system\/base,views\/views.ajax,views\/views.module,views_slideshow\/jquery_hoverIntent,views_slideshow\/pager_bullets,views_slideshow\/widget_info,views_slideshow_cycle\/jquery_cycle,views_slideshow_cycle\/json2,views_slideshow_cycle\/views_slideshow_cycle","theme":"mvd","theme_token":null},"ajaxTrustedUrl":{"\/en\/search":true},"viewsSlideshowPagerFields":{"block_slider-block_1":{"bottom":{"activatePauseOnHover":null}},"slideshow-block_1":{"bottom":{"activatePauseOnHover":null}}},"viewsSlideshowPager":{"block_slider-block_1":{"bottom":{"type":"viewsSlideshowPagerBullets"}},"slideshow-block_1":{"bottom":{"type":"viewsSlideshowPagerBullets"}}},"viewsSlideshowCycle":{"#views_slideshow_cycle_main_block_slider-block_1":{"num_divs":4,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"block_slider-block_1","effect":"fade","transition_advanced":1,"timeout":3000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"fixed_height":1,"items_per_slide":1,"items_per_slide_first":0,"items_per_slide_first_number":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"},"#views_slideshow_cycle_main_news_ticker-block_1":{"num_divs":5,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"news_ticker-block_1","effect":"scrollLeft","transition_advanced":1,"timeout":5000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"fixed_height":1,"items_per_slide":1,"items_per_slide_first":0,"items_per_slide_first_number":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"},"#views_slideshow_cycle_main_slideshow-block_1":{"num_divs":5,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"slideshow-block_1","effect":"fade","transition_advanced":1,"timeout":2000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"fixed_height":1,"items_per_slide":1,"items_per_slide_first":0,"items_per_slide_first_number":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"}},"viewsSlideshow":{"block_slider-block_1":{"methods":{"goToSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowSlideCounter","viewsSlideshowPager"],"transitionEnd":[]},"paused":0},"news_ticker-block_1":{"methods":{"goToSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowSlideCounter","viewsSlideshowPager"],"transitionEnd":[]},"paused":0},"slideshow-block_1":{"methods":{"goToSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowSlideCounter","viewsSlideshowPager"],"transitionEnd":[]},"paused":0}},"views":{"ajax_path":"\/index.php\/en\/views\/ajax","ajaxViews":{"views_dom_id:3ab4e2572c7a73374477f7fab8f45306cfc9e3d65aebe7a207a2b93f9fdfac11":{"view_name":"news_ticker","view_display_id":"block_1","view_args":"","view_path":"\/node","view_base_path":"old-news","view_dom_id":"3ab4e2572c7a73374477f7fab8f45306cfc9e3d65aebe7a207a2b93f9fdfac11","pager_element":0}}},"superfish":{"superfish-main":{"id":"superfish-main","sf":{"animation":{"opacity":"show","height":"show"},"speed":"fast"},"plugins":{"smallscreen":{"mode":"window_width","title":"Main navigation"},"supposition":true,"supersubs":true}}},"search_api_autocomplete":{"search_content":{"auto_submit":true}},"blazy":{"loadInvisible":false,"offset":100,"saveViewportOffsetDelay":50,"validateDelay":25},"blazyIo":{"enabled":false,"disconnect":false,"rootMargin":"0px","threshold":[0]},"user":{"uid":0,"permissionsHash":"bb13c26e2f55382c4a634f2cc0f691b351815f736efd9d1101edb3beead98a48"}}</script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery/jquery.min.js?v=3.4.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery-once/jquery.once.min.js?v=2.2.0"></script>
<script src="https://mvd.kerala.gov.in/core/misc/drupalSettingsLoader.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/misc/drupal.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/misc/drupal.init.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/data-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/disable-selection-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/form-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/labels-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/jquery-1-7-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/scroll-parent-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/tabbable-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/unique-id-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/version-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/escape-selector-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/focusable-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/ie-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/keycode-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/plugin-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/safe-active-element-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/safe-blur-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/widget-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/blazy/js/dblazy.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/blazy/js/blazy.load.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/core/misc/autocomplete.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/themes/mvd/js/custom.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/js/views_slideshow.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/libraries/json2/json2.js?v=2"></script>
<script src="https://mvd.kerala.gov.in/libraries/jquery.cycle/jquery.cycle.all.js?v=3.0.3"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/modules/views_slideshow_cycle/js/views_slideshow_cycle.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/libraries/jquery.hoverIntent/jquery.hoverIntent.js?v=1.9"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery-form/jquery.form.min.js?v=4.22"></script>
<script src="https://mvd.kerala.gov.in/core/misc/progress.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/misc/ajax.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/themes/stable/js/ajax.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/modules/views/js/base.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/modules/views/js/ajax_view.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/position-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/widgets/menu-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/widgets/autocomplete-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/search_api_autocomplete/js/search_api_autocomplete.js?rr8q49"></script>

				
				
				<script type="text/javascript">
var _userway_config = {
/* uncomment the following line to override default position*/
/* position: '1', */
/* uncomment the following line to override default size (values: small, large)*/
/* size: 'small', */
/* uncomment the following line to override default language (e.g., fr, de, es, he, nl, etc.)*/
/* language: 'en-US', */
/* uncomment the following line to override color set via widget (e.g., #053f67)*/
/* color: '#053f67', */
/* uncomment the following line to override type set via widget(1=person, 2=chair, 3=eye)*/
/* type: '2', */
/* uncomment the following line to override support on mobile devices*/
/* mobile: true, */
account: 'wFuknyxNOi'
};
</script>
<script type="text/javascript" src="https://cdn.userway.org/widget.js"></script>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-V53G52QEPJ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-V53G52QEPJ');
</script>

  </body>

<!-- Mirrored from mvd.kerala.gov.in/en by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 May 2023 06:52:27 GMT -->
</html>
