<!DOCTYPE html>
<html  lang="en" dir="ltr" prefix="content: http://purl.org/rss/1.0/modules/content/  dc: http://purl.org/dc/terms/  foaf: http://xmlns.com/foaf/0.1/  og: http://ogp.me/ns#  rdfs: http://www.w3.org/2000/01/rdf-schema#  schema: http://schema.org/  sioc: http://rdfs.org/sioc/ns#  sioct: http://rdfs.org/sioc/types#  skos: http://www.w3.org/2004/02/skos/core#  xsd: http://www.w3.org/2001/XMLSchema# ">
  
<!-- Mirrored from mvd.kerala.gov.in/en by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 May 2023 06:52:27 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8" />
<meta name="Generator" content="Drupal 8 (https://www.drupal.org)" />
<meta name="MobileOptimized" content="width" />
<meta name="HandheldFriendly" content="true" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="shortcut icon" href="https://mvd.kerala.gov.in/sites/default/files/favicon_0.ico" type="image/vnd.microsoft.icon" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

    <title>Home | Motor Vehicle Department</title>
    <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/ajax-progress.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/align.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/autocomplete-loading.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/fieldgroup.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/container-inline.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/clearfix.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/details.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/hidden.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/item-list.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/js.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/nowrap.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/position-container.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/progress.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/reset-appearance.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/resize.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/sticky-header.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/system-status-counter.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/system-status-report-counters.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/system-status-report-general-info.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/tabledrag.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/tablesort.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/tree-child.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/views/views.module.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/css/views-slideshow-pager-bullets.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/modules/views_slideshow_cycle/css/views_slideshow_cycle.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/themes/base/core.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/themes/base/menu.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/themes/base/autocomplete.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/blazy.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/components/blazy.column.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/components/blazy.grid.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/components/blazy.ratio.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/components/blazy.loading.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/themes/base/theme.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/search_api_autocomplete/css/search_api_autocomplete.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/bootstrap.min.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/font-awesome.min.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/style.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/tabs.css?rr8q49" />
<link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/custom.css?rr8q49" />

    
<!--[if lte IE 8]>
<script src="/core/assets/vendor/html5shiv/html5shiv.min.js?v=3.7.3"></script>
<![endif]-->
<script src="https://mvd.kerala.gov.in/libraries/blazy/blazy.js?v=1.x"></script>

		
<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet" type="text/css"> 
<link href='http://fonts.googleapis.com/css?family=Armata' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
		
  </head>
  <body class="path-frontpage">
    <a href="#main-content" class="visually-hidden focusable skip-link">
      Skip to main content
    </a>
    
      <div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas>
    <div id="header-wrap" class="clr">   	
	
		<div id="topbar-wrap">
  <div id="topbar" class="container row clr">
    <div id="topnavigation" class="col span_4"> 
      	    <div>
    <div id="block-topsocialicons">
  
    
      
            <div><div class="social"><a href="https://m.facebook.com/mvd.socialmedia/" id="" rel="" target="_blank" title=""><img alt="Facebook" data-entity-type="file" data-entity-uuid="df4faea8-b070-49e1-bf83-b428b90e006b" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-facebook-48.png" class="align-left" /></a></div>

<div class="social"><a href="https://twitter.com/KeralaMvd" id="" rel="" target="_blank" title=""><img alt="Twitter" data-entity-type="file" data-entity-uuid="5826b440-f9a2-4246-add0-47c7bbd076aa" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-twitter-48.png" class="align-left" /></a></div>

<div class="social"><a href="https://www.youtube.com/channel/UCguF4r6jOGqO2-OVrEDaplw/videos" id="" rel="" target="_blank" title=""><img alt="Youtube" data-entity-type="file" data-entity-uuid="f555c39c-3367-414a-911f-35ff85e71fb8" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-youtube-squared-48.png" class="align-left" /></a></div>

<div class="social"><a href="https://instagram.com/mvd_kerala?igshid=h5korves8y26" id="" rel="" target="_blank" title=""><img alt="Instagram" data-entity-type="file" data-entity-uuid="696e2ba9-16fc-4404-b5f9-34c777b252f3" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/instagram_0.png" class="align-left" /></a></div>
</div>
      
  </div>
<div class="views-exposed-form" data-drupal-selector="views-exposed-form-search-content-page-1" id="block-exposedformsearch-contentpage-1">
  
    
      <form action="https://mvd.kerala.gov.in/en/search" method="get" id="views-exposed-form-search-content-page-1" accept-charset="UTF-8">
  <div class="js-form-item form-item js-form-type-search-api-autocomplete form-item-search-api-fulltext js-form-item-search-api-fulltext">
      <label for="edit-search-api-fulltext">Search</label>
        <input data-drupal-selector="edit-search-api-fulltext" data-search-api-autocomplete-search="search_content" class="form-autocomplete form-text" data-autocomplete-path="/en/search_api_autocomplete/search_content?display=page_1&amp;&amp;filter=search_api_fulltext" type="text" id="edit-search-api-fulltext" name="search_api_fulltext" value="" size="30" maxlength="128" />

        </div>
<div data-drupal-selector="edit-actions" class="form-actions js-form-wrapper form-wrapper" id="edit-actions"><input data-drupal-selector="edit-submit-search-content" type="submit" id="edit-submit-search-content" value="🔍" class="button js-form-submit form-submit" />
</div>


</form>

  </div>

  </div>
    
       
    </div>
    <div id="top" class="col span_6">
	  <div id="top-nav">					
	    		  <div>
    <nav role="navigation" aria-labelledby="block-topmenu-menu" id="block-topmenu">
            
  <h2 class="visually-hidden" id="block-topmenu-menu">Top menu</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/en/imageGallery" data-drupal-link-system-path="imageGallery">Gallery</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/rti" data-drupal-link-system-path="node/133">RTI</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/rts" data-drupal-link-system-path="node/134">RTS</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/webLinks" data-drupal-link-system-path="webLinks">Web links</a>
              </li>
        </ul>
  


  </nav>

  </div>
    
			  </div>
	</div>
	<div id="lang" class="col span_2">
	  <div id="lang-switch">					
	    		  <div>
    <div class="language-switcher-language-url" id="block-languageswitcher" role="navigation">
  
    
      <ul class="links"><li hreflang="en" data-drupal-link-system-path="&lt;front&gt;" class="en is-active"><a href="https://mvd.kerala.gov.in/en" class="language-link is-active" hreflang="en" data-drupal-link-system-path="&lt;front&gt;">English</a></li><li hreflang="ml" data-drupal-link-system-path="&lt;front&gt;" class="ml"><a href="https://mvd.kerala.gov.in/ml" class="language-link" hreflang="ml" data-drupal-link-system-path="&lt;front&gt;">മലയാളം</a></li></ul>
  </div>

  </div>
    
			  </div>
	</div>
  </div>       
</div>         

<div id="header" class="container row clr">                     
  <div id="logo" class="col span_4">
    	  <div>
    <div id="block-sitebranding">
  
    
        <a href="https://mvd.kerala.gov.in/en" title="Home" rel="home">
      <img src="https://mvd.kerala.gov.in/sites/default/files/animated-logo.gif" alt="Home" />
    </a>
    	
		
	
  
 
</div>

  </div>
    
	            
  </div>                       
			
  <div id="navbar-wrap" class="col span_7">
    <nav id="navbar">
	  <div id="navigation"> 
		 		   <div>
    <div id="block-mainnavigation-2">
  
    
      
<ul id="superfish-main" class="menu sf-menu sf-main sf-vertical sf-style-none">
  
<li id="main-menu-link-contentcab5141f-ce74-4412-bcac-6b342d2b89b5" class="active-trail sf-depth-1 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en" class="sf-depth-1" title="Home">🏠</a></li><li id="main-menu-link-content5916198a-2c46-49a4-98f8-d225e645d340" class="sf-depth-1 menuparent"><a href="https://mvd.kerala.gov.in/index.php/en/about-department" class="sf-depth-1 menuparent" title="വകുപ്പിനെക്കുറിച്ച്">About us</a><ul><li id="main-menu-link-content919442c9-1030-4f04-804d-31ae9c9d2ee6" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/about-department" class="sf-depth-2">About the Department</a></li><li id="main-menu-link-content15fec050-984c-48e6-992d-a4b4a187f68f" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/services" class="sf-depth-2">Services</a></li><li id="main-menu-link-content08377c65-6848-4e19-8b84-a93ae19b3d71" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/organization-structure" class="sf-depth-2">Organisation Structure</a></li><li id="main-menu-link-content31cf4fc3-dd0c-45a5-934a-9c3b066eaa21" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/our-mission" class="sf-depth-2">Our Mission and Vision</a></li><li id="main-menu-link-content3d05ec27-feef-44b5-bc0e-1842944eba68" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/our-commitment" class="sf-depth-2">Our Commitment</a></li><li id="main-menu-link-contentb0d95d89-00a1-46c3-8513-d814438a047d" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/head-office" class="sf-depth-2">Head office</a></li><li id="main-menu-link-content4ebfc646-4a07-4616-af9d-86fee066720b" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/projects" class="sf-depth-2">Projects</a></li><li id="main-menu-link-contentca6c7aa0-a043-4eeb-9a7f-6cf4ca38b00c" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/node/1293" class="sf-depth-2">Transport Commissioners</a></li></ul></li><li id="main-menu-link-content9e84adb4-def2-4b20-b418-93b55473200f" class="sf-depth-1 menuparent"><a href="https://mvd.kerala.gov.in/index.php/en/dashboards" class="sf-depth-1 menuparent" title="Dashboards">Dashboards</a><ul><li id="main-menu-link-content86c3ed8c-ab81-4434-8175-112d6d8bb93f" class="sf-depth-2 sf-no-children"><a href="https://vahan.parivahan.gov.in/vahan4dashboard/" target="_blank" class="sf-depth-2 sf-external" title="Vahan Dashboard">Vahan Dashboard</a></li><li id="main-menu-link-contentbd6bd467-68ec-4d8e-873d-57490c5f2151" class="sf-depth-2 sf-no-children"><a href="https://sarathi.parivahan.gov.in/SarathiReport/sarathiHomePublic.do" target="_blank" class="sf-depth-2 sf-external" title="Sarathi Dashboard">Sarathi Dashboard</a></li><li id="main-menu-link-contente775b138-0a28-4ce3-9b7c-5937ff9fb800" class="sf-depth-2 sf-no-children"><a href="https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/dashboardForPendingApplication.xhtml" target="_blank" class="sf-depth-2 sf-external" title="Vahan Pendency Dashboard">Vahan Pendency Dashboard</a></li></ul></li><li id="main-menu-link-contenteafb64f6-5924-470b-8eff-8d681460b898" class="sf-depth-1 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/tenders" class="sf-depth-1">Tenders</a></li><li id="main-menu-link-contentaa43410e-c8c7-4ac3-80a7-4d1142628977" class="sf-depth-1 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/directory" class="sf-depth-1">Contact Us</a></li><li id="main-menu-link-content6adc79be-7531-41df-8775-b4ae4466d504" class="sf-depth-1 menuparent"><a href="login.php" class="sf-depth-1 menuparent">Login</a></li>
</ul>

  </div>

  </div>
    
		 	   </div>				
	</nav>                
  </div>  
		
  <span class="hiddenmenu" onclick="openNav()">&#9776;</span>                    	
  <div id="myNav" class="overlay">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <div class="overlay-content">
		<div id="leftbarw" class="col span_6 clr" >
									
									<div id="overlaymenu">								   
																		  <div>
    <nav role="navigation" aria-labelledby="block-aboutmvd-2-menu" id="block-aboutmvd-2">
      
  <h2 id="block-aboutmvd-2-menu">എംവിഡിയെക്കുറിച്ച്</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/en/about-department" data-drupal-link-system-path="node/5">About MVD</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/contact" data-drupal-link-system-path="contact">Contact/ Feedback</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/directory" data-drupal-link-system-path="directory">Directory</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/head-office" data-drupal-link-system-path="node/9">Head Office</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/organization-structure" data-drupal-link-system-path="node/6">Organization Structure</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/our-commitment" data-drupal-link-system-path="node/8">Our Commitment</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/our-mission" data-drupal-link-system-path="node/7">Our Mission</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/projects" data-drupal-link-system-path="projects">Projects</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/services" data-drupal-link-system-path="node/10">Services</a>
              </li>
        </ul>
  


  </nav>

  </div>
    
																		</div>
									
									
									<div id="overlaymenu">
									
																		  <div>
    <nav role="navigation" aria-labelledby="block-roadsafety-menu" id="block-roadsafety">
      
  <h2 id="block-roadsafety-menu">റോഡ് സുരക്ഷ</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/important-road-regulations-0">Important Road Regulations</a>
              </li>
          <li>
        <a href="#">Road Accident Statitics</a>
              </li>
          <li>
        <a href="#">Road Safety Videos</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/road-safety-club-0">Road safety club</a>
              </li>
          <li>
        <a href="#">Safety Messages</a>
              </li>
          <li>
        <a href="#">Safety Posters</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/speed-limits-kerala-0">Speed Limits in Kerala</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/traffic-rules-0">Traffic Rules</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/traffic-signs">Traffic Signs</a>
              </li>
          <li>
        <a href="#">Vehicle Population</a>
              </li>
        </ul>
  


  </nav>

  </div>
    
																		</div>
									
									
									<div id="overlaymenu">
									
																		  <div>
    <nav role="navigation" aria-labelledby="block-onlineservices-menu" id="block-onlineservices">
      
  <h2 id="block-onlineservices-menu">ഓൺലൈൻ സേവനങ്ങൾ</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/en/citizenCorner" data-drupal-link-system-path="citizenCorner">Online Services</a>
                                <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/en/ePayment" data-drupal-link-system-path="ePayment">E Payment</a>
              </li>
          <li>
        <a href="https://smartweb.keralamvd.gov.in/kmvdnew/services/licensedateallot/lldtallot.php" target="_blank">DL Test date change</a>
              </li>
          <li>
        <a href="https://smartweb.keralamvd.gov.in/kmvdnew/services/etax/etaxmain.php" target="_blank">Online Tax Payment</a>
              </li>
          <li>
        <a href="https://smartweb.keralamvd.gov.in/kmvdnew/services/etax/etaxpubprint.php" target="_blank">Online Tax Token</a>
              </li>
          <li>
        <a href="https://sarathi.parivahan.gov.in/sarathiservice/sarathiHomePublic.do?stCd=KL">Licenses</a>
              </li>
          <li>
        <a href="https://vahan.parivahan.gov.in/vahanservice/vahan/ui/statevalidation/homepage.xhtml">Vehicles</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/staPermit" data-drupal-link-system-path="staPermit">STA Permit</a>
              </li>
          <li>
        <a href="#">Others</a>
              </li>
        </ul>
  
              </li>
        </ul>
  


  </nav>

  </div>
    
																		</div>
								  
								  
								  
								<!--  <br clear="all">
									
									<div id="overlaymenu">
																		  <div>
    <nav role="navigation" aria-labelledby="block-informationservices-menu" id="block-informationservices">
      
  <h2 id="block-informationservices-menu">വിവര സേവനങ്ങൾ</h2>
  

        
              <ul>
              <li>
        <a href="/en/citizenCorner" data-drupal-link-system-path="citizenCorner">Information Services</a>
                                <ul>
              <li>
        <a href="/applicationstatus">Application Status</a>
              </li>
          <li>
        <a href="/tax-0">Tax</a>
              </li>
          <li>
        <a href="/cess-0">CESS</a>
              </li>
          <li>
        <a href="/fees-0">Fees</a>
              </li>
          <li>
        <a href="/downloads">Forms</a>
              </li>
          <li>
        <a href="/citizen-call-centre">Citizen Call centre</a>
              </li>
          <li>
        <a href="/downloads">Downloads</a>
              </li>
          <li>
        <a href="/pollutiontestingcentres">Pollution Testing Centres</a>
              </li>
        </ul>
  
              </li>
        </ul>
  


  </nav>

  </div>
    
																		</div>
									
									
									
									<div id="overlaymenu">
																		  <div>
    <nav role="navigation" aria-labelledby="block-employeescorner-menu" id="block-employeescorner">
      
  <h2 id="block-employeescorner-menu">ജീവനക്കാരുടെ കോർണർ</h2>
  

        
              <ul>
              <li>
        <a href="/en/employeeCorner" data-drupal-link-system-path="employeeCorner">Employees Corner</a>
                                <ul>
              <li>
        <a href="https://smartweb.keralamvd.gov.in/kmvdnew/login.html" target="_blank">Employees Login</a>
              </li>
          <li>
        <a href="/en/ecPostings" data-drupal-link-system-path="ecPostings">Postings</a>
              </li>
          <li>
        <a href="/en/ecPromotions" data-drupal-link-system-path="ecPromotions">Promotions</a>
              </li>
          <li>
        <a href="/en/ecSelectLists" data-drupal-link-system-path="ecSelectLists">Select Lists</a>
              </li>
          <li>
        <a href="/en/ecSeniorityLists" data-drupal-link-system-path="ecSeniorityLists">Seniority lists</a>
              </li>
          <li>
        <a href="/en/ecTransfers" data-drupal-link-system-path="ecTransfers">Transfers</a>
              </li>
        </ul>
  
              </li>
        </ul>
  


  </nav>

  </div>
    
																		</div>-->
								  
								  
									  </div>
									
									
									
									
									
									
									<div id="rightbarw" class="col span_6 clr">
									<div id="overlaymenu">
								   									  <div>
    <nav role="navigation" aria-labelledby="block-informationservices-menu" id="block-informationservices">
      
  <h2 id="block-informationservices-menu">വിവര സേവനങ്ങൾ</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/en/citizenCorner" data-drupal-link-system-path="citizenCorner">Information Services</a>
                                <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/applicationstatus">Application Status</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/tax-0">Tax</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/cess-0">CESS</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/fees-0">Fees</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/downloads">Forms</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/citizen-call-centre">Citizen Call centre</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/downloads">Downloads</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/pollutiontestingcentres">Pollution Testing Centres</a>
              </li>
        </ul>
  
              </li>
        </ul>
  


  </nav>

  </div>
    
																		</div>
									
									
									<div id="overlaymenu">
																		  <div>
    <nav role="navigation" aria-labelledby="block-employeescorner-menu" id="block-employeescorner">
      
  <h2 id="block-employeescorner-menu">ജീവനക്കാരുടെ കോർണർ</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/en/employeeCorner" data-drupal-link-system-path="employeeCorner">Employees Corner</a>
                                <ul>
              <li>
        <a href="https://smartweb.keralamvd.gov.in/kmvdnew/login.html" target="_blank">Employees Login</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/ecPostings" data-drupal-link-system-path="ecPostings">Postings</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/ecPromotions" data-drupal-link-system-path="ecPromotions">Promotions</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/ecSelectLists" data-drupal-link-system-path="ecSelectLists">Select Lists</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/ecSeniorityLists" data-drupal-link-system-path="ecSeniorityLists">Seniority lists</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/ecTransfers" data-drupal-link-system-path="ecTransfers">Transfers</a>
              </li>
        </ul>
  
              </li>
        </ul>
  


  </nav>

  </div>
    
																		</div>
									
									
									<div id="overlaymenu">
																		  <div>
    <nav role="navigation" aria-labelledby="block-aboutportal-menu" id="block-aboutportal">
      
  <h2 id="block-aboutportal-menu">പോർട്ടലിനെക്കുറിച്ച്</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/screen-reader-access" title="Screen Reader Access">Screen Reader Access</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/disclaimer" data-drupal-link-system-path="node/80">Disclaimer</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/copy-right-policy" data-drupal-link-system-path="node/81">Copy Right Policy</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/privacy-policy" data-drupal-link-system-path="node/82">Privacy Policy</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/webLinks" data-drupal-link-system-path="webLinks">Weblinks</a>
              </li>
        </ul>
  


  </nav>
<nav role="navigation" aria-labelledby="block-topmenu-2-menu" id="block-topmenu-2">
      
  <h2 id="block-topmenu-2-menu">മറ്റുള്ളവ</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/en/imageGallery" data-drupal-link-system-path="imageGallery">Gallery</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/rti" data-drupal-link-system-path="node/133">RTI</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/rts" data-drupal-link-system-path="node/134">RTS</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/webLinks" data-drupal-link-system-path="webLinks">Web links</a>
              </li>
        </ul>
  


  </nav>

  </div>
    
																		
									</div>
							
									  </div>
						
						
					</div>
	  					
	  </div>      
  </div> 
</div>
	
 	
	
    <div id="slide-wrap">
		<!--<img src="/themes/mvd/images/slider_img.jpg">-->
							  <div>
    <div class="views-element-container" id="block-views-block-slideshow-block-1">
  
    
      <div><div class="js-view-dom-id-a0df8c162864a77041bc1153e2fbf02be8c535f5a6aefd87e2dccfaf9a230681">
  
  
  

  
  
  

    <div class="skin-default">
    
    <div id="views_slideshow_cycle_main_slideshow-block_1" class="views_slideshow_cycle_main views_slideshow_main">
    <div id="views_slideshow_cycle_teaser_section_slideshow-block_1"  class="views_slideshow_cycle_teaser_section">
     <div id="views_slideshow_cycle_div_slideshow-block_1_0"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-1 views-row-odd">
      <div  class="views-row views-row-0 views-row-odd views-row-first">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://play.google.com/store/apps/details?id=com.nic.mparivahan&amp;pli=1" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/nextgen-en.jpg" width="1920" height="450" alt="mParivahan app" typeof="Image" />

</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_slideshow-block_1_1"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-2 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-1 views-row-even">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://mvd.kerala.gov.in/ml/vidyavahan-app" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/vidyavahini-app_1.jpg" width="1920" height="450" alt="Vidyavahan App" typeof="Image" />

</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_slideshow-block_1_2"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-3 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-2 views-row-odd">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://mvd.kerala.gov.in/index.php/index.php/en/fine-remittance" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/mvd-fine.jpg" width="1920" height="450" alt="MVD fine-remittance" typeof="Image" />

</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_slideshow-block_1_3"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-4 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-3 views-row-even">
  <div class="views-field views-field-field-cc-link"><div class="field-content">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/banner_1.jpg" width="1920" height="450" alt="MVD pilots the Oxygen Move" typeof="Image" />

</div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_slideshow-block_1_4"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-5 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-4 views-row-odd views-row-last">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://vahan.parivahan.gov.in/fancy/faces/public/login.xhtml" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/Slideshow/fancy-choice-en.jpg" width="1920" height="450" alt="Fancy Number" typeof="Image" />

</a></div></div>
</div>

  </div>

  </div>

</div>


          <div class="views-slideshow-controls-bottom clearfix">
        
<ul class="widget_pager widget_pager_bottom views-slideshow-pager-bullets views_slideshow_pager_field" id="widget_pager_bottom_slideshow-block_1"><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_0">0</li><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_1">1</li><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_2">2</li><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_3">3</li><li id="views_slideshow_pager_field_item_bottom_slideshow-block_1_4">4</li></ul>

      </div>
        </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
							
	</div>	
</div>

<div id="latestnews-wrap"> 

		<div id="news1" class="container row clr">
			
			<span class = "content">
								  <div>
    <div class="views-element-container" id="block-views-block-news-ticker-block-1">
  
    
      <div><div class="js-view-dom-id-3ab4e2572c7a73374477f7fab8f45306cfc9e3d65aebe7a207a2b93f9fdfac11">
  
  
  

      <header>
      <div class="heading">Latest News :</div>
    </header>
  
  
  

    <div class="skin-default">
    
    <div id="views_slideshow_cycle_main_news_ticker-block_1" class="views_slideshow_cycle_main views_slideshow_main">
    <div id="views_slideshow_cycle_teaser_section_news_ticker-block_1"  class="views_slideshow_cycle_teaser_section">
     <div id="views_slideshow_cycle_div_news_ticker-block_1_0"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-1 views-row-odd">
      <div  class="views-row views-row-0 views-row-odd views-row-first">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1703" hreflang="ml">Press release regarding Driving license.</a></span></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_news_ticker-block_1_1"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-2 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-1 views-row-even">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1702" hreflang="ml">E-SUBSIDY FOR ELECTRIC AUTO RICKSHAW - SANCTIONED FOR THE PERIOD FROM 24/01/2023 TO 31/03/2023</a></span></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_news_ticker-block_1_2"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-3 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-2 views-row-odd">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1693" hreflang="ml">REGIONAL TRANSPORT AUTHORITY, KANNUR DECISION OF RTA Dtd. 07.03.2023</a></span></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_news_ticker-block_1_3"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-4 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-3 views-row-even">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1692" hreflang="ml">REGIONAL TRANSPORT AUTHORITY, VATAKARA AGENDA FOR THE RTA MEETING TO BE HELD ON 11.04.2023</a></span></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_news_ticker-block_1_4"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-5 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-4 views-row-odd views-row-last">
  <div class="views-field views-field-title"><span class="field-content"><a href="https://mvd.kerala.gov.in/index.php/ml/node/1691" hreflang="ml">DECISION OF THE MEETING OF REGIONAL TRANSPORT AUTHORITY ERNAKULAM HELD ON 23-01-2023</a></span></div>
</div>

  </div>

  </div>

</div>


        </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
							</span>
		</div>
	</div>

  <div><div id="user1-wrap">
<div class="container row clr" id="user1">

<main><section class="">
  

                                <form method="post" class="form-group"   action="log.php">
                             
                                <div class="row g-10">
                                <center><h2 style="font-size: 30px;color:red;">Login</h2></center>
                                
                                    <div class="col-md-10">
                                    <label style="color:black;" for="email">Email</label>
                                        <div class="form-floating">
                                          
                                            <input type="email" class="form-control" id="email" name="email" >
                                           
                                        </div>
                                    </div>

                                    <div class="col-10">
                                    <label style="color:black;"  for="">Password</label>
                                        <div class="form-floating">
                                         
                                            <input type="password" class="form-control" id="subject" name="password" >
                                          
                                        </div>
                                    </div>
                                   
                                    <div class="col-6">
                                        <button class="btn btn-danger w-100 py-3" name="submit" type="submit">Submit</button>
                                    </div>
                                </div>
                            </form><br>
</section></main></div>
</div>
</div>

<div class = "leaders">
	<div class="row container ">
						  <div>
    <div id="block-leaders">
  
    
      
            <div><div class="column4 first">
<div class="card"><img alt="Chief minister" data-entity-type="file" data-entity-uuid="f818dc67-57e5-4cca-b4cd-2acb26f38cd9" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/cm.jpg" /><div class="container centered">
<h1 class="team-name">Shri Pinarayi Vijayan</h1>

<p class="title">Hon'ble Chief Minister, Kerala</p>
</div>
</div>
</div>

<div class="column4">
<div class="card"><img alt="Transport Minister" data-entity-type="file" data-entity-uuid="a7d3ba31-ff81-46ab-a0ad-73c7f3d6a15f" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/tm-new.jpg" /><div class="container centered">
<h1>Shri Antony Raju</h1>

<p class="title">Hon'ble Minister for Transport, Kerala</p>
</div>
</div>
</div>

<div class="column4">
<div class="card"><img alt="Transport Commissioner" data-entity-type="file" data-entity-uuid="43999052-7bcf-4012-904f-8f55d67032b7" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/tcnew1_2.jpg" /><div class="container centered">
<h1>Shri S Sreejith, IPS, ADGP</h1>

<p class="title">Transport Commissioner</p>
</div>
</div>
</div>

<div class="column4 last">
<div class="card"><img alt="Additional Transport Commissioner" data-entity-type="file" data-entity-uuid="ec54a526-bd7d-489a-9c3f-cf2e0456a5ec" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/atc-new_0.jpg" /><div class="container centered">
<h1>Shri Pramoj Sanker P S , IOFS</h1>

<p class="title">Additional Transport Commissioner</p>
</div>
</div>
</div>
</div>
      
  </div>
<div id="block-homemainicons">
  
    
      

      
  </div>

  </div>

					
	</div> 
</div>


<div id="user1-wrap">
	
</div>



<div id="wrapper"> 
	
	<div class="container row clr"></div>
	<!--<div id="news1-wrap">
		<div id="news1" class="container row clr">  			
  			<div class="imageHolder">
    		
								
			</div>
			<div class="section2 group">
									
			</div>						
		</div>
	</div> -->
	
	
	<div id="news1-wrap">
		<div id="news1" class="container row clr">
					</div>
	</div>

	<!--<div id="news1-wrap" style="background: #FFFFFF;">
				  <div>
    <div id="block-homefootericons">
  
    
      
            <div><div class="section4 group">
<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://www.india.gov.in/" target="_blank"><img alt="India Government" data-entity-type="file" data-entity-uuid="75d4eb80-8a98-47bc-b925-c62384162f56" src="/sites/default/files/inline-images/1.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://kerala.gov.in/" target="_blank"><img alt="Kerala Government" data-entity-type="file" data-entity-uuid="d8d3ff6e-7156-44e7-befa-9dc153004926" src="/sites/default/files/inline-images/2.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://www.keralacm.gov.in/" target="_blank"><img alt="Kerala CM" data-entity-type="file" data-entity-uuid="228dd30d-fea0-40d9-8243-a0a540eef803" src="/sites/default/files/inline-images/3.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://roadsafety.kerala.gov.in/" target="_blank"><img alt="Road Safety Kerala" data-entity-type="file" data-entity-uuid="632b4e35-95d4-4ad7-b787-e5fc488c354c" src="/sites/default/files/inline-images/4.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://parivahan.gov.in/parivahan/" target="_blank"><img alt="Parivahan Sewa" data-entity-type="file" data-entity-uuid="f42a7f7a-2d0e-4fb6-a498-dc0db9bb862e" src="/sites/default/files/inline-images/5.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://www.natpac.kerala.gov.in/" target="_blank"><img alt="NATPAC" data-entity-type="file" data-entity-uuid="4554f282-fba2-4b5a-9c68-dff19d9038b9" src="/sites/default/files/inline-images/6.png" /></a></div>
</div>
</div>
</div>
      
  </div>

  </div>
    
			</div> -->
	                                                            
	<!--<div id="box-wrap" class="container row clr">	</div>-->

	<div id="news1-wrap">
		<div id="news1" class="container row clr connect">									
			<div class="section2 group">
				<div class="coloumn2 span_1_of_2">
					<div class="childbox">
						<h1></h1>
						<div style="background: #FFF; padding: 3px; height: auto;">														
														  <div>
    <div class="views-element-container" id="block-views-block-block-slider-block-1">
  
      <h2>Updates</h2>
    
      <div><div class="js-view-dom-id-b8a5f341f5f7ad07bf5fd8d1e84433018275413ed4ad183a0aa76e2c48dbe72f">
  
  
  

  
  
  

    <div class="skin-default">
    
    <div id="views_slideshow_cycle_main_block_slider-block_1" class="views_slideshow_cycle_main views_slideshow_main">
    <div id="views_slideshow_cycle_teaser_section_block_slider-block_1"  class="views_slideshow_cycle_teaser_section">
     <div id="views_slideshow_cycle_div_block_slider-block_1_0"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-1 views-row-odd">
      <div  class="views-row views-row-0 views-row-odd views-row-first">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://sarathi.parivahan.gov.in/SarathiReport/sarathiHomePublic.do" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/styles/frontbanner2/public/2021-09/SARATHI-DASHBOARD_0.jpg?itok=ClHfKr1k" width="575" height="260" alt="Sarathi Dashboard" typeof="Image" />


</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_block_slider-block_1_1"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-2 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-1 views-row-even">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://vahan.parivahan.gov.in/vahan4dashboard/" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/styles/frontbanner2/public/2021-09/vahan-dashboard.jpg?itok=1XXUkWPH" width="575" height="260" alt="Vahan Dashboard" typeof="Image" />


</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_block_slider-block_1_2"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-3 views_slideshow_cycle_hidden views-row-odd">
      <div  class="views-row views-row-2 views-row-odd">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://mvd.kerala.gov.in/sites/default/files/2019-03/fancy.pdf" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/styles/frontbanner2/public/2019-03/vahan_0.jpg?itok=pakkLHHA" width="575" height="260" alt="Vahan" typeof="Image" />


</a></div></div>
</div>

  </div>

     <div id="views_slideshow_cycle_div_block_slider-block_1_3"  class="views_slideshow_cycle_slide views_slideshow_slide views-row-4 views_slideshow_cycle_hidden views-row-even">
      <div  class="views-row views-row-3 views-row-even views-row-last">
  <div class="views-field views-field-field-cc-link"><div class="field-content"><a href="https://mvd.kerala.gov.in/index.php/index.php/en/revision-of-auto-taxi-hire-charges" target="_blank">  <img src="https://mvd.kerala.gov.in/sites/default/files/styles/frontbanner2/public/2019-02/1.jpg?itok=f-21pxcc" width="575" height="260" alt="Revision of hire rate of auto rickshaw" typeof="Image" />


</a></div></div>
</div>

  </div>

  </div>

</div>


          <div class="views-slideshow-controls-bottom clearfix">
        
<ul class="widget_pager widget_pager_bottom views-slideshow-pager-bullets views_slideshow_pager_field" id="widget_pager_bottom_block_slider-block_1"><li id="views_slideshow_pager_field_item_bottom_block_slider-block_1_0">0</li><li id="views_slideshow_pager_field_item_bottom_block_slider-block_1_1">1</li><li id="views_slideshow_pager_field_item_bottom_block_slider-block_1_2">2</li><li id="views_slideshow_pager_field_item_bottom_block_slider-block_1_3">3</li></ul>

      </div>
        </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
								
						</div>
					</div>
				</div>		
			
				<div class="coloumn2 span_1_of_2">
					<div class="childbox">
						<div class="imageHolder">
							<h1></h1>
							<div style="background: #fff; padding:0 20px 20px 20px;">								
																  <div>
    <div class="views-element-container" id="block-views-block-google-map-block-1-2">
  
      <h2>Locate us</h2>
    
      <div><div class="js-view-dom-id-3938092e3a2461cc93df022cbd46f94f11cd8f79d4caf7a2fab333f229cd6bf8">
  
  
  

  
  
  

      <div class="views-row"><div class="views-field views-field-field-gmap"><div class="field-content">  <iframe width="100%" height="236px" frameborder="0" style="border:0" src="https://maps.google.com/maps?hl=en&amp;q=Transport+Commissinarate+thycaus+trivandrum&amp;t=m&amp;z=14&amp;output=embed"></iframe>
  <p class="simple-gmap-link"><a href="https://maps.google.com/maps?q=Transport+Commissinarate+thycaus+trivandrum&amp;hl=en&amp;t=m&amp;z=14" target="_blank">View larger map</a></p>
</div></div></div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
														
							</div>
						</div>						
					</div>
				</div>		
			</div>					  			
		</div>
	</div>
</div>


<div id="user-wrap" class = "logo-wrap">
	<div id="user2" class="container row clr">
	
		  <div>
    <div id="block-homefootericons">
  
    
      
            <div><div class="section4 group">
<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://www.india.gov.in/" target="_blank"><img alt="India Government" data-entity-type="file" data-entity-uuid="75d4eb80-8a98-47bc-b925-c62384162f56" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/1.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://kerala.gov.in/" target="_blank"><img alt="Kerala Government" data-entity-type="file" data-entity-uuid="d8d3ff6e-7156-44e7-befa-9dc153004926" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/2.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://www.keralacm.gov.in/" target="_blank"><img alt="Kerala CM" data-entity-type="file" data-entity-uuid="228dd30d-fea0-40d9-8243-a0a540eef803" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/3.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://roadsafety.kerala.gov.in/" target="_blank"><img alt="Road Safety Kerala" data-entity-type="file" data-entity-uuid="632b4e35-95d4-4ad7-b787-e5fc488c354c" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/4.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="https://parivahan.gov.in/parivahan/" target="_blank"><img alt="Parivahan Sewa" data-entity-type="file" data-entity-uuid="f42a7f7a-2d0e-4fb6-a498-dc0db9bb862e" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/5.png" /></a></div>
</div>

<div class="coloumn4 span_1_of_6">
<div class="childbox"><a href="http://www.natpac.kerala.gov.in/" target="_blank"><img alt="NATPAC" data-entity-type="file" data-entity-uuid="4554f282-fba2-4b5a-9c68-dff19d9038b9" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/6.png" /></a></div>
</div>
</div>
</div>
      
  </div>

  </div>
    
			            
	</div>
</div>


<div id="user2-wrap" class = "footer-wrap">
	<div id="user2" class="container row clr">
		<div class="section4 group">
			
			<div class="coloumn4 span_1_of_3 block block1">
				<div class="childbox box">
					
										  <div>
    <div class="views-element-container" id="block-views-block-video-gallery-block-1">
  
    
      <div><div class="js-view-dom-id-88a7a707c7a43c679ea99df95c73085ca8df9006411a7ba38c4a2a004e6d6e42">
  
  
  

  
  
  

  <ul data-blazy="" class="blazy blazy--view blazy--view--video-gallery blazy--view--video-gallery--block-1 blazy--grid block-column block-count-1 small-block-column-1 medium-block-column-1 large-block-column-1" id="blazy-views-video-gallery-block-1-1"><li class="grid"><div class="grid__content"><div class="views-field views-field-body"><div class="field-content"><p><iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen="" frameborder="0" height="215" src="https://www.youtube.com/embed/p9gLMdPYELs" title="YouTube video player" width="360"></iframe></p>
</div></div><div class="views-field views-field-nothing"><strong class="field-content"><a href="https://www.youtube.com/channel/UCguF4r6jOGqO2-OVrEDaplw/videos" target="_blank"><strong>more videos</strong></a></strong></div></div>
</li></ul>
    

  
  

  
  
</div>
</div>

  </div>
<div id="block-footeraboutusblock">
  
      <h2>About us</h2>
    
      
            <div><p style="text-align:left;">The Motor Vehicles Department is regulated by the Government of Kerala in terms of policy formulation and its implementation.  The Department is administered by the Transport Commissioner who is the Head of Department.</p>

<h4><strong>Connect us</strong></h4>

<div class="social"><a href="https://m.facebook.com/mvd.socialmedia/" id="" rel="" target="_blank" title=""><img alt="Facebook" data-entity-type="file" data-entity-uuid="df4faea8-b070-49e1-bf83-b428b90e006b" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-facebook-48.png" class="align-left" /></a></div>

<div class="social"><a href="https://twitter.com/KeralaMvd" id="" rel="" target="_blank" title=""><img alt="Twitter" data-entity-type="file" data-entity-uuid="5826b440-f9a2-4246-add0-47c7bbd076aa" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-twitter-48.png" class="align-left" /></a></div>

<div class="social"><a href="https://www.youtube.com/channel/UCguF4r6jOGqO2-OVrEDaplw/videos" id="" rel="" target="_blank" title=""><img alt="Youtube" data-entity-type="file" data-entity-uuid="f555c39c-3367-414a-911f-35ff85e71fb8" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-youtube-squared-48.png" class="align-left" /></a></div>

<div class="social"><a href="https://instagram.com/mvd_kerala?igshid=h5korves8y26" id="" rel="" target="_blank" title=""><img alt="Instagram" data-entity-type="file" data-entity-uuid="696e2ba9-16fc-4404-b5f9-34c777b252f3" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/instagram_0.png" class="align-left" /></a></div>

<p> </p>

<h4><br /><a href="http://old.mvd.kerala.gov.in/" style="color:#ffcc00!important;" target="_blank" title="old.mvd.kerala.gov.in">Visit Old Website</a></h4>
</div>
      
  </div>

  </div>
    
						
				</div>
			</div>
		
		
			<div class="coloumn4 span_1_of_3 block block2">
				<div class="childbox box">
										  <div>
    <div class="views-element-container" id="block-views-block-footer-contact-block-1">
  
    
      <div><div class="js-view-dom-id-87290f60699ddcee9030658a7a2cc2a1246e7865f1b60bdb5aa52ff0d1407ac3">
  
  
  

  
  
  

      <div class="views-view-grid horizontal cols-1 clearfix">
            <div class="views-row clearfix row-1">
                  <div class="views-col col-1" style="width: 100%;"><div class="views-field views-field-body"><div class="field-content"><ul><li>
	<p style="text-align:left;"><strong>Helpdesk </strong>Online Services<br />
	0471-2328799 (10:15 AM - 05:00 PM)<br />
	(Lunch break 01:15 P.M - 2:00 P.M)<br />
	email: ssgcell[dot]mvd[at]kerala[dot]gov[dot]in</p>
	</li>
	<li>
	<p style="text-align:left;"><strong>General Enquiry </strong>(Public Relation Officer):<br />
	(10:15 AM - 05:00 PM) (Lunch break 01:15 P.M - 2:00 P.M)<br />
	Transport Commissionerate: 0471-2333317<br />
	e-mail: tcoffice[dot]mvd[at]kerala[dot]gov[dot]in</p>
	</li>
	<li>
	<p style="text-align:left;"><strong>RTO / JRTO Contact Numbers</strong><br /><br /><a href="https://mvd.kerala.gov.in/directory" style="color:#ffcc00!important;" title="https://mvd.kerala.gov.in/directory">https://mvd.kerala.gov.in/directory</a></p>
	</li>
	<li>
	<p style="text-align:left;"><strong>Grievance</strong></p>
	</li>
	<li>
	<p style="text-align:left;">91 88 96 11 00 (10:15 AM - 05:00 PM)<br />
	(Lunch break 01:15 P.M - 2:00 P.M)<br />
	email: complaints[dot]mvd[at]kerala[dot]gov[dot]in</p>
	</li>
</ul></div></div></div>
              </div>
      </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
						
				</div>
			</div>	
			
			<div class="coloumn4 span_1_of_3 block3">
				<div class="childbox">
										  <div>
    <div class="views-element-container" id="block-views-block-footer-contact-block-2">
  
    
      <div><div class="js-view-dom-id-13d928f1d88a6b94d7a3e9c24f5efe5d62273b6735cc1d59cb4f1f7a3612cc10">
  
  
  

  
  
  

      <div class="views-view-grid horizontal cols-1 clearfix">
            <div class="views-row clearfix row-1">
                  <div class="views-col col-1" style="width: 100%;"><div class="views-field views-field-body"><div class="field-content"><ul><li style="list-style:none;">
	<p><strong>Helpdesk:</strong></p>

	<p style="text-align:left;"><strong>Vahan : </strong>Vehicle Registration/Fitness/Tax/Permit/Fancy, Dealer<br />
	helpdesk-vahan[at]gov[dot]in,<br />
	+91-120-2459168    6:00 AM-10:00 PM</p>

	<p style="text-align:left;"><strong>Sarathi : </strong>Licence<br />
	helpdesk-sarathi[at]gov[dot]in<br />
	+91-120-2459169    6:00 AM-10:00 PM</p>

	<p style="text-align:left;">eChallan<br />
	helpdesk-echallan[at]gov[dot]in<br />
	+91-120-2459171    6:00 AM-10:00 PM</p>

	<p style="text-align:left;">mParivahan<br />
	helpdesk-mparivahan[at]gov[dot]in<br />
	+91-120-2459171    6:00 AM-10:00 PM</p>

	<div style="background:#313131; padding:10px 0 10px 10px;">
	<p style="text-align:left;"><strong>Kerala Government Call Center</strong></p>

	<p style="text-align:left;">  BSNL  - 155300 , 0471 2335523       </p>
	</div>
	<br /><strong>For more details: <a href="https://mvd.kerala.gov.in/directory" style="color:#ffcc00!important;" target="_blank">Click here</a></strong></li>
</ul></div></div></div>
              </div>
      </div>

    

  
  

  
  
</div>
</div>

  </div>

  </div>
    
						
				</div>
			</div>	
				
		</div>	            
	</div>
</div>

<!-- FOOTER START  --> 
<div id="footer-wrap" >
  <div id="footer" class="container row clr">
    <div id="footer-nav">  
      	    <div>
    <nav role="navigation" aria-labelledby="block-aboutportal-2-menu" id="block-aboutportal-2">
            
  <h2 class="visually-hidden" id="block-aboutportal-2-menu">About Portal</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/screen-reader-access" title="Screen Reader Access">Screen Reader Access</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/disclaimer" data-drupal-link-system-path="node/80">Disclaimer</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/copy-right-policy" data-drupal-link-system-path="node/81">Copy Right Policy</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/privacy-policy" data-drupal-link-system-path="node/82">Privacy Policy</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/webLinks" data-drupal-link-system-path="webLinks">Weblinks</a>
              </li>
        </ul>
  


  </nav>

  </div>
    
	  	
    </div>
	<div id="footer-text">
	  <div class = "copyrig" style="display: inline-block;">Motor Vehicles Department Copyright &copy; 2023. All Rights Reserved. </div>
	  <div class = "credit" >Designed and Maintained by <a href="http://www.cdit.org/" target="_blank">C-Dit</a></div>
	</div> 
  </div>
</div>
 







  </div>

    
    <script type="application/json" data-drupal-selector="drupal-settings-json">{"path":{"baseUrl":"\/","scriptPath":null,"pathPrefix":"en\/","currentPath":"node","currentPathIsAdmin":false,"isFront":true,"currentLanguage":"en"},"pluralDelimiter":"\u0003","suppressDeprecationErrors":true,"ajaxPageState":{"libraries":"blazy\/column,blazy\/grid,blazy\/load,blazy\/ratio,core\/html5shiv,mvd\/framework,search_api_autocomplete\/search_api_autocomplete,superfish\/superfish,superfish\/superfish_hoverintent,superfish\/superfish_smallscreen,superfish\/superfish_supersubs,superfish\/superfish_supposition,system\/base,views\/views.ajax,views\/views.module,views_slideshow\/jquery_hoverIntent,views_slideshow\/pager_bullets,views_slideshow\/widget_info,views_slideshow_cycle\/jquery_cycle,views_slideshow_cycle\/json2,views_slideshow_cycle\/views_slideshow_cycle","theme":"mvd","theme_token":null},"ajaxTrustedUrl":{"\/en\/search":true},"viewsSlideshowPagerFields":{"block_slider-block_1":{"bottom":{"activatePauseOnHover":null}},"slideshow-block_1":{"bottom":{"activatePauseOnHover":null}}},"viewsSlideshowPager":{"block_slider-block_1":{"bottom":{"type":"viewsSlideshowPagerBullets"}},"slideshow-block_1":{"bottom":{"type":"viewsSlideshowPagerBullets"}}},"viewsSlideshowCycle":{"#views_slideshow_cycle_main_block_slider-block_1":{"num_divs":4,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"block_slider-block_1","effect":"fade","transition_advanced":1,"timeout":3000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"fixed_height":1,"items_per_slide":1,"items_per_slide_first":0,"items_per_slide_first_number":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"},"#views_slideshow_cycle_main_news_ticker-block_1":{"num_divs":5,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"news_ticker-block_1","effect":"scrollLeft","transition_advanced":1,"timeout":5000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"fixed_height":1,"items_per_slide":1,"items_per_slide_first":0,"items_per_slide_first_number":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"},"#views_slideshow_cycle_main_slideshow-block_1":{"num_divs":5,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"slideshow-block_1","effect":"fade","transition_advanced":1,"timeout":2000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"fixed_height":1,"items_per_slide":1,"items_per_slide_first":0,"items_per_slide_first_number":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"}},"viewsSlideshow":{"block_slider-block_1":{"methods":{"goToSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowSlideCounter","viewsSlideshowPager"],"transitionEnd":[]},"paused":0},"news_ticker-block_1":{"methods":{"goToSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowSlideCounter","viewsSlideshowPager"],"transitionEnd":[]},"paused":0},"slideshow-block_1":{"methods":{"goToSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowSlideCounter","viewsSlideshowPager"],"transitionEnd":[]},"paused":0}},"views":{"ajax_path":"\/index.php\/en\/views\/ajax","ajaxViews":{"views_dom_id:3ab4e2572c7a73374477f7fab8f45306cfc9e3d65aebe7a207a2b93f9fdfac11":{"view_name":"news_ticker","view_display_id":"block_1","view_args":"","view_path":"\/node","view_base_path":"old-news","view_dom_id":"3ab4e2572c7a73374477f7fab8f45306cfc9e3d65aebe7a207a2b93f9fdfac11","pager_element":0}}},"superfish":{"superfish-main":{"id":"superfish-main","sf":{"animation":{"opacity":"show","height":"show"},"speed":"fast"},"plugins":{"smallscreen":{"mode":"window_width","title":"Main navigation"},"supposition":true,"supersubs":true}}},"search_api_autocomplete":{"search_content":{"auto_submit":true}},"blazy":{"loadInvisible":false,"offset":100,"saveViewportOffsetDelay":50,"validateDelay":25},"blazyIo":{"enabled":false,"disconnect":false,"rootMargin":"0px","threshold":[0]},"user":{"uid":0,"permissionsHash":"bb13c26e2f55382c4a634f2cc0f691b351815f736efd9d1101edb3beead98a48"}}</script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery/jquery.min.js?v=3.4.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery-once/jquery.once.min.js?v=2.2.0"></script>
<script src="https://mvd.kerala.gov.in/core/misc/drupalSettingsLoader.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/misc/drupal.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/misc/drupal.init.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/data-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/disable-selection-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/form-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/labels-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/jquery-1-7-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/scroll-parent-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/tabbable-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/unique-id-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/version-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/escape-selector-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/focusable-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/ie-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/keycode-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/plugin-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/safe-active-element-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/safe-blur-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/widget-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/blazy/js/dblazy.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/blazy/js/blazy.load.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/core/misc/autocomplete.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/themes/mvd/js/custom.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/js/views_slideshow.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/libraries/json2/json2.js?v=2"></script>
<script src="https://mvd.kerala.gov.in/libraries/jquery.cycle/jquery.cycle.all.js?v=3.0.3"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/modules/views_slideshow_cycle/js/views_slideshow_cycle.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/libraries/jquery.hoverIntent/jquery.hoverIntent.js?v=1.9"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery-form/jquery.form.min.js?v=4.22"></script>
<script src="https://mvd.kerala.gov.in/core/misc/progress.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/misc/ajax.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/themes/stable/js/ajax.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/modules/views/js/base.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/modules/views/js/ajax_view.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/position-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/widgets/menu-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/widgets/autocomplete-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/search_api_autocomplete/js/search_api_autocomplete.js?rr8q49"></script>

				
				
				<script type="text/javascript">
var _userway_config = {
/* uncomment the following line to override default position*/
/* position: '1', */
/* uncomment the following line to override default size (values: small, large)*/
/* size: 'small', */
/* uncomment the following line to override default language (e.g., fr, de, es, he, nl, etc.)*/
/* language: 'en-US', */
/* uncomment the following line to override color set via widget (e.g., #053f67)*/
/* color: '#053f67', */
/* uncomment the following line to override type set via widget(1=person, 2=chair, 3=eye)*/
/* type: '2', */
/* uncomment the following line to override support on mobile devices*/
/* mobile: true, */
account: 'wFuknyxNOi'
};
</script>
<script type="text/javascript" src="https://cdn.userway.org/widget.js"></script>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-V53G52QEPJ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-V53G52QEPJ');
</script>

  </body>

<!-- Mirrored from mvd.kerala.gov.in/en by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 May 2023 06:52:27 GMT -->
</html>
