<?php
session_start();
include('connection.php');

if (isset($_POST['submit']))
{	
$username=$_POST['email']; 
$password=$_POST['password']; 

if($username=="mvd@gmail.com" && $password=="mvd")
{
	$_SESSION['user']='mvd';
	header("location:score.php");
}

	

		
		else{

			
		header("location:login.php?st=fail");
		}

}
?>
 
 



