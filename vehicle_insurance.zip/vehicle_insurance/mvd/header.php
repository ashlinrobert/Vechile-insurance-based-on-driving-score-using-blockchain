<!DOCTYPE html>
<html  lang="en" dir="ltr" prefix="content: http://purl.org/rss/1.0/modules/content/  dc: http://purl.org/dc/terms/  foaf: http://xmlns.com/foaf/0.1/  og: http://ogp.me/ns#  rdfs: http://www.w3.org/2000/01/rdf-schema#  schema: http://schema.org/  sioc: http://rdfs.org/sioc/ns#  sioct: http://rdfs.org/sioc/types#  skos: http://www.w3.org/2004/02/skos/core#  xsd: http://www.w3.org/2001/XMLSchema# ">
   <!-- Mirrored from mvd.kerala.gov.in/en by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 May 2023 06:52:27 GMT -->
   <!-- Added by HTTrack -->
   <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
   <!-- /Added by HTTrack -->
   <head>
      <meta charset="utf-8" />
      <meta name="Generator" content="Drupal 8 (https://www.drupal.org)" />
      <meta name="MobileOptimized" content="width" />
      <meta name="HandheldFriendly" content="true" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <link rel="shortcut icon" href="https://mvd.kerala.gov.in/sites/default/files/favicon_0.ico" type="image/vnd.microsoft.icon" />
      <title>Home | Motor Vehicle Department</title>
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/ajax-progress.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/align.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/autocomplete-loading.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/fieldgroup.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/container-inline.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/clearfix.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/details.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/hidden.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/item-list.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/js.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/nowrap.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/position-container.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/progress.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/reset-appearance.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/resize.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/sticky-header.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/system-status-counter.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/system-status-report-counters.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/system-status-report-general-info.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/tabledrag.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/tablesort.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/system/components/tree-child.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/themes/stable/css/views/views.module.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/css/views-slideshow-pager-bullets.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/modules/views_slideshow_cycle/css/views_slideshow_cycle.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/themes/base/core.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/themes/base/menu.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/themes/base/autocomplete.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/blazy.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/components/blazy.column.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/components/blazy.grid.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/components/blazy.ratio.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/blazy/css/components/blazy.loading.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/themes/base/theme.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/modules/contrib/search_api_autocomplete/css/search_api_autocomplete.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/bootstrap.min.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/font-awesome.min.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/style.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/tabs.css?rr8q49" />
      <link rel="stylesheet" media="all" href="https://mvd.kerala.gov.in/themes/mvd/css/custom.css?rr8q49" />
      <!--[if lte IE 8]>
      <script src="/core/assets/vendor/html5shiv/html5shiv.min.js?v=3.7.3"></script>
      <![endif]-->
      <script src="https://mvd.kerala.gov.in/libraries/blazy/blazy.js?v=1.x"></script>
      <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet" type="text/css">
      <link href='http://fonts.googleapis.com/css?family=Armata' rel='stylesheet' type='text/css'>
      <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
   </head>
   <body class="path-frontpage">
      <a href="#main-content" class="visually-hidden focusable skip-link">
      Skip to main content
      </a>
      <div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas>
      <div id="header-wrap" class="clr">
         <div id="topbar-wrap">
            <div id="topbar" class="container row clr">
               <div id="topnavigation" class="col span_4">
                  <div>
                     <div id="block-topsocialicons">
                        <div>
                           <div class="social"><a href="https://m.facebook.com/mvd.socialmedia/" id="" rel="" target="_blank" title=""><img alt="Facebook" data-entity-type="file" data-entity-uuid="df4faea8-b070-49e1-bf83-b428b90e006b" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-facebook-48.png" class="align-left" /></a></div>
                           <div class="social"><a href="https://twitter.com/KeralaMvd" id="" rel="" target="_blank" title=""><img alt="Twitter" data-entity-type="file" data-entity-uuid="5826b440-f9a2-4246-add0-47c7bbd076aa" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-twitter-48.png" class="align-left" /></a></div>
                           <div class="social"><a href="https://www.youtube.com/channel/UCguF4r6jOGqO2-OVrEDaplw/videos" id="" rel="" target="_blank" title=""><img alt="Youtube" data-entity-type="file" data-entity-uuid="f555c39c-3367-414a-911f-35ff85e71fb8" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/icons8-youtube-squared-48.png" class="align-left" /></a></div>
                           <div class="social"><a href="https://instagram.com/mvd_kerala?igshid=h5korves8y26" id="" rel="" target="_blank" title=""><img alt="Instagram" data-entity-type="file" data-entity-uuid="696e2ba9-16fc-4404-b5f9-34c777b252f3" src="https://mvd.kerala.gov.in/sites/default/files/inline-images/instagram_0.png" class="align-left" /></a></div>
                        </div>
                     </div>
                     <div class="views-exposed-form" data-drupal-selector="views-exposed-form-search-content-page-1" id="block-exposedformsearch-contentpage-1">
                        <form action="https://mvd.kerala.gov.in/en/search" method="get" id="views-exposed-form-search-content-page-1" accept-charset="UTF-8">
                           <div class="js-form-item form-item js-form-type-search-api-autocomplete form-item-search-api-fulltext js-form-item-search-api-fulltext">
                              <label for="edit-search-api-fulltext">Search</label>
                              <input data-drupal-selector="edit-search-api-fulltext" data-search-api-autocomplete-search="search_content" class="form-autocomplete form-text" data-autocomplete-path="/en/search_api_autocomplete/search_content?display=page_1&amp;&amp;filter=search_api_fulltext" type="text" id="edit-search-api-fulltext" name="search_api_fulltext" value="" size="30" maxlength="128" />
                           </div>
                           <div data-drupal-selector="edit-actions" class="form-actions js-form-wrapper form-wrapper" id="edit-actions"><input data-drupal-selector="edit-submit-search-content" type="submit" id="edit-submit-search-content" value="🔍" class="button js-form-submit form-submit" /></div>
                        </form>
                     </div>
                  </div>
               </div>
               <div id="top" class="col span_6">
                  <div id="top-nav">
                     <div>
                        <nav role="navigation" aria-labelledby="block-topmenu-menu" id="block-topmenu">
                           <h2 class="visually-hidden" id="block-topmenu-menu">Top menu</h2>
                           <ul>
                              <li>
                                 <a href="https://mvd.kerala.gov.in/en/imageGallery" data-drupal-link-system-path="imageGallery">Gallery</a>
                              </li>
                              <li>
                                 <a href="https://mvd.kerala.gov.in/en/rti" data-drupal-link-system-path="node/133">RTI</a>
                              </li>
                              <li>
                                 <a href="https://mvd.kerala.gov.in/en/rts" data-drupal-link-system-path="node/134">RTS</a>
                              </li>
                              <li>
                                 <a href="https://mvd.kerala.gov.in/en/webLinks" data-drupal-link-system-path="webLinks">Web links</a>
                              </li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
               <div id="lang" class="col span_2">
                  <div id="lang-switch">
                     <div>
                        <div class="language-switcher-language-url" id="block-languageswitcher" role="navigation">
                           <ul class="links">
                              <li hreflang="en" data-drupal-link-system-path="&lt;front&gt;" class="en is-active"><a href="https://mvd.kerala.gov.in/en" class="language-link is-active" hreflang="en" data-drupal-link-system-path="&lt;front&gt;">English</a></li>
                              <li hreflang="ml" data-drupal-link-system-path="&lt;front&gt;" class="ml"><a href="https://mvd.kerala.gov.in/ml" class="language-link" hreflang="ml" data-drupal-link-system-path="&lt;front&gt;">മലയാളം</a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div id="header" class="container row clr">
            <div id="logo" class="col span_4">
               <div>
                  <div id="block-sitebranding">
                     <a href="https://mvd.kerala.gov.in/en" title="Home" rel="home">
                     <img src="https://mvd.kerala.gov.in/sites/default/files/animated-logo.gif" alt="Home" />
                     </a>
                  </div>
               </div>
            </div>
            <div id="navbar-wrap" class="col span_7">
               <nav id="navbar">
                  <div id="navigation">
                     <div>
                        <div id="block-mainnavigation-2">
                           <ul id="superfish-main" class="menu sf-menu sf-main sf-vertical sf-style-none">
                              <?php
							  error_reporting(0);
								session_start();
								if($_SESSION['user']=='mvd')
								{
							  ?>
							  
							  <li id="main-menu-link-content6adc79be-7531-41df-8775-b4ae4466d504" class="sf-depth-1 menuparent">
                                 <a href="users.php" class="sf-depth-1 menuparent">Users</a>
                              </li>
							  <li id="main-menu-link-content6adc79be-7531-41df-8775-b4ae4466d504" class="sf-depth-1 menuparent">
                                 <a href="score.php" class="sf-depth-1 menuparent">Driving Scores</a>
                              </li>
							  <li id="main-menu-link-content6adc79be-7531-41df-8775-b4ae4466d504" class="sf-depth-1 menuparent">
                                 <a href="ins.php" class="sf-depth-1 menuparent">Insurance Applications</a>
                              </li>
							  <li id="main-menu-link-content6adc79be-7531-41df-8775-b4ae4466d504" class="sf-depth-1 menuparent">
                                 <a href="logout.php" class="sf-depth-1 menuparent">Logout</a>
                              </li>
							  
							  <?php
								}
								else
								{
							  ?>
							  <li id="main-menu-link-contentcab5141f-ce74-4412-bcac-6b342d2b89b5" class="active-trail sf-depth-1 sf-no-children"><a href=" index.php" class="sf-depth-1" title="Home">🏠</a></li>
                              <li id="main-menu-link-content5916198a-2c46-49a4-98f8-d225e645d340" class="sf-depth-1 menuparent">
                                 <a href="https://mvd.kerala.gov.in/index.php/en/about-department" class="sf-depth-1 menuparent" title="വകുപ്പിനെക്കുറിച്ച്">About us</a>
                                 <ul>
                                    <li id="main-menu-link-content919442c9-1030-4f04-804d-31ae9c9d2ee6" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/about-department" class="sf-depth-2">About the Department</a></li>
                                    <li id="main-menu-link-content15fec050-984c-48e6-992d-a4b4a187f68f" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/services" class="sf-depth-2">Services</a></li>
                                    <li id="main-menu-link-content08377c65-6848-4e19-8b84-a93ae19b3d71" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/organization-structure" class="sf-depth-2">Organisation Structure</a></li>
                                    <li id="main-menu-link-content31cf4fc3-dd0c-45a5-934a-9c3b066eaa21" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/our-mission" class="sf-depth-2">Our Mission and Vision</a></li>
                                    <li id="main-menu-link-content3d05ec27-feef-44b5-bc0e-1842944eba68" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/our-commitment" class="sf-depth-2">Our Commitment</a></li>
                                    <li id="main-menu-link-contentb0d95d89-00a1-46c3-8513-d814438a047d" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/head-office" class="sf-depth-2">Head office</a></li>
                                    <li id="main-menu-link-content4ebfc646-4a07-4616-af9d-86fee066720b" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/projects" class="sf-depth-2">Projects</a></li>
                                    <li id="main-menu-link-contentca6c7aa0-a043-4eeb-9a7f-6cf4ca38b00c" class="sf-depth-2 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/node/1293" class="sf-depth-2">Transport Commissioners</a></li>
                                 </ul>
                              </li>
                              <li id="main-menu-link-content9e84adb4-def2-4b20-b418-93b55473200f" class="sf-depth-1 menuparent">
                                 <a href="https://mvd.kerala.gov.in/index.php/en/dashboards" class="sf-depth-1 menuparent" title="Dashboards">Dashboards</a>
                                 <ul>
                                    <li id="main-menu-link-content86c3ed8c-ab81-4434-8175-112d6d8bb93f" class="sf-depth-2 sf-no-children"><a href="https://vahan.parivahan.gov.in/vahan4dashboard/" target="_blank" class="sf-depth-2 sf-external" title="Vahan Dashboard">Vahan Dashboard</a></li>
                                    <li id="main-menu-link-contentbd6bd467-68ec-4d8e-873d-57490c5f2151" class="sf-depth-2 sf-no-children"><a href="https://sarathi.parivahan.gov.in/SarathiReport/sarathiHomePublic.do" target="_blank" class="sf-depth-2 sf-external" title="Sarathi Dashboard">Sarathi Dashboard</a></li>
                                    <li id="main-menu-link-contente775b138-0a28-4ce3-9b7c-5937ff9fb800" class="sf-depth-2 sf-no-children"><a href="https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/dashboardForPendingApplication.xhtml" target="_blank" class="sf-depth-2 sf-external" title="Vahan Pendency Dashboard">Vahan Pendency Dashboard</a></li>
                                 </ul>
                              </li>
                              <li id="main-menu-link-contenteafb64f6-5924-470b-8eff-8d681460b898" class="sf-depth-1 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/tenders" class="sf-depth-1">Tenders</a></li>
                              <li id="main-menu-link-contentaa43410e-c8c7-4ac3-80a7-4d1142628977" class="sf-depth-1 sf-no-children"><a href="https://mvd.kerala.gov.in/index.php/en/directory" class="sf-depth-1">Contact Us</a></li>
                              <li id="main-menu-link-content6adc79be-7531-41df-8775-b4ae4466d504" class="sf-depth-1 menuparent">
                                 <a href="login.php" class="sf-depth-1 menuparent">Login</a>
                              </li>
							  <?php
								}
							  ?>
                           </ul>
                        </div>
                     </div>
                  </div>
               </nav>
            </div>
            <span class="hiddenmenu" onclick="openNav()">&#9776;</span>                    	
            <div id="myNav" class="overlay">
               <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
               <div class="overlay-content">
                  <div id="leftbarw" class="col span_6 clr" >
                     <div id="overlaymenu">
                        <div>
                           <nav role="navigation" aria-labelledby="block-aboutmvd-2-menu" id="block-aboutmvd-2">
                              <h2 id="block-aboutmvd-2-menu">എംവിഡിയെക്കുറിച്ച്</h2>
                              <ul>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/about-department" data-drupal-link-system-path="node/5">About MVD</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/contact" data-drupal-link-system-path="contact">Contact/ Feedback</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/directory" data-drupal-link-system-path="directory">Directory</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/head-office" data-drupal-link-system-path="node/9">Head Office</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/organization-structure" data-drupal-link-system-path="node/6">Organization Structure</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/our-commitment" data-drupal-link-system-path="node/8">Our Commitment</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/our-mission" data-drupal-link-system-path="node/7">Our Mission</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/projects" data-drupal-link-system-path="projects">Projects</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/services" data-drupal-link-system-path="node/10">Services</a>
                                 </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                     <div id="overlaymenu">
                        <div>
                           <nav role="navigation" aria-labelledby="block-roadsafety-menu" id="block-roadsafety">
                              <h2 id="block-roadsafety-menu">റോഡ് സുരക്ഷ</h2>
                              <ul>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/important-road-regulations-0">Important Road Regulations</a>
                                 </li>
                                 <li>
                                    <a href="#">Road Accident Statitics</a>
                                 </li>
                                 <li>
                                    <a href="#">Road Safety Videos</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/road-safety-club-0">Road safety club</a>
                                 </li>
                                 <li>
                                    <a href="#">Safety Messages</a>
                                 </li>
                                 <li>
                                    <a href="#">Safety Posters</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/speed-limits-kerala-0">Speed Limits in Kerala</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/traffic-rules-0">Traffic Rules</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/traffic-signs">Traffic Signs</a>
                                 </li>
                                 <li>
                                    <a href="#">Vehicle Population</a>
                                 </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                     <div id="overlaymenu">
                        <div>
                           <nav role="navigation" aria-labelledby="block-onlineservices-menu" id="block-onlineservices">
                              <h2 id="block-onlineservices-menu">ഓൺലൈൻ സേവനങ്ങൾ</h2>
                              <ul>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/citizenCorner" data-drupal-link-system-path="citizenCorner">Online Services</a>
                                    <ul>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/en/ePayment" data-drupal-link-system-path="ePayment">E Payment</a>
                                       </li>
                                       <li>
                                          <a href="https://smartweb.keralamvd.gov.in/kmvdnew/services/licensedateallot/lldtallot.php" target="_blank">DL Test date change</a>
                                       </li>
                                       <li>
                                          <a href="https://smartweb.keralamvd.gov.in/kmvdnew/services/etax/etaxmain.php" target="_blank">Online Tax Payment</a>
                                       </li>
                                       <li>
                                          <a href="https://smartweb.keralamvd.gov.in/kmvdnew/services/etax/etaxpubprint.php" target="_blank">Online Tax Token</a>
                                       </li>
                                       <li>
                                          <a href="https://sarathi.parivahan.gov.in/sarathiservice/sarathiHomePublic.do?stCd=KL">Licenses</a>
                                       </li>
                                       <li>
                                          <a href="https://vahan.parivahan.gov.in/vahanservice/vahan/ui/statevalidation/homepage.xhtml">Vehicles</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/en/staPermit" data-drupal-link-system-path="staPermit">STA Permit</a>
                                       </li>
                                       <li>
                                          <a href="#">Others</a>
                                       </li>
                                    </ul>
                                 </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                     <!--  <br clear="all">
                        <div id="overlaymenu">
                        									  <div>
                        <nav role="navigation" aria-labelledby="block-informationservices-menu" id="block-informationservices">
                        
                        <h2 id="block-informationservices-menu">വിവര സേവനങ്ങൾ</h2>
                        
                        
                        
                             <ul>
                             <li>
                        <a href="/en/citizenCorner" data-drupal-link-system-path="citizenCorner">Information Services</a>
                                               <ul>
                             <li>
                        <a href="/applicationstatus">Application Status</a>
                             </li>
                         <li>
                        <a href="/tax-0">Tax</a>
                             </li>
                         <li>
                        <a href="/cess-0">CESS</a>
                             </li>
                         <li>
                        <a href="/fees-0">Fees</a>
                             </li>
                         <li>
                        <a href="/downloads">Forms</a>
                             </li>
                         <li>
                        <a href="/citizen-call-centre">Citizen Call centre</a>
                             </li>
                         <li>
                        <a href="/downloads">Downloads</a>
                             </li>
                         <li>
                        <a href="/pollutiontestingcentres">Pollution Testing Centres</a>
                             </li>
                        </ul>
                        
                             </li>
                        </ul>
                        
                        
                        
                        </nav>
                        
                        </div>
                        
                        									</div>
                        
                        
                        
                        <div id="overlaymenu">
                        									  <div>
                        <nav role="navigation" aria-labelledby="block-employeescorner-menu" id="block-employeescorner">
                        
                        <h2 id="block-employeescorner-menu">ജീവനക്കാരുടെ കോർണർ</h2>
                        
                        
                        
                             <ul>
                             <li>
                        <a href="/en/employeeCorner" data-drupal-link-system-path="employeeCorner">Employees Corner</a>
                                               <ul>
                             <li>
                        <a href="https://smartweb.keralamvd.gov.in/kmvdnew/login.html" target="_blank">Employees Login</a>
                             </li>
                         <li>
                        <a href="/en/ecPostings" data-drupal-link-system-path="ecPostings">Postings</a>
                             </li>
                         <li>
                        <a href="/en/ecPromotions" data-drupal-link-system-path="ecPromotions">Promotions</a>
                             </li>
                         <li>
                        <a href="/en/ecSelectLists" data-drupal-link-system-path="ecSelectLists">Select Lists</a>
                             </li>
                         <li>
                        <a href="/en/ecSeniorityLists" data-drupal-link-system-path="ecSeniorityLists">Seniority lists</a>
                             </li>
                         <li>
                        <a href="/en/ecTransfers" data-drupal-link-system-path="ecTransfers">Transfers</a>
                             </li>
                        </ul>
                        
                             </li>
                        </ul>
                        
                        
                        
                        </nav>
                        
                        </div>
                        
                        									</div>-->
                  </div>
                  <div id="rightbarw" class="col span_6 clr">
                     <div id="overlaymenu">
                        <div>
                           <nav role="navigation" aria-labelledby="block-informationservices-menu" id="block-informationservices">
                              <h2 id="block-informationservices-menu">വിവര സേവനങ്ങൾ</h2>
                              <ul>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/citizenCorner" data-drupal-link-system-path="citizenCorner">Information Services</a>
                                    <ul>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/applicationstatus">Application Status</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/tax-0">Tax</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/cess-0">CESS</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/fees-0">Fees</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/downloads">Forms</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/citizen-call-centre">Citizen Call centre</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/downloads">Downloads</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/pollutiontestingcentres">Pollution Testing Centres</a>
                                       </li>
                                    </ul>
                                 </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                     <div id="overlaymenu">
                        <div>
                           <nav role="navigation" aria-labelledby="block-employeescorner-menu" id="block-employeescorner">
                              <h2 id="block-employeescorner-menu">ജീവനക്കാരുടെ കോർണർ</h2>
                              <ul>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/employeeCorner" data-drupal-link-system-path="employeeCorner">Employees Corner</a>
                                    <ul>
                                       <li>
                                          <a href="https://smartweb.keralamvd.gov.in/kmvdnew/login.html" target="_blank">Employees Login</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/en/ecPostings" data-drupal-link-system-path="ecPostings">Postings</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/en/ecPromotions" data-drupal-link-system-path="ecPromotions">Promotions</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/en/ecSelectLists" data-drupal-link-system-path="ecSelectLists">Select Lists</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/en/ecSeniorityLists" data-drupal-link-system-path="ecSeniorityLists">Seniority lists</a>
                                       </li>
                                       <li>
                                          <a href="https://mvd.kerala.gov.in/en/ecTransfers" data-drupal-link-system-path="ecTransfers">Transfers</a>
                                       </li>
                                    </ul>
                                 </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                     <div id="overlaymenu">
                        <div>
                           <nav role="navigation" aria-labelledby="block-aboutportal-menu" id="block-aboutportal">
                              <h2 id="block-aboutportal-menu">പോർട്ടലിനെക്കുറിച്ച്</h2>
                              <ul>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/screen-reader-access" title="Screen Reader Access">Screen Reader Access</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/disclaimer" data-drupal-link-system-path="node/80">Disclaimer</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/copy-right-policy" data-drupal-link-system-path="node/81">Copy Right Policy</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/privacy-policy" data-drupal-link-system-path="node/82">Privacy Policy</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/webLinks" data-drupal-link-system-path="webLinks">Weblinks</a>
                                 </li>
                              </ul>
                           </nav>
                           <nav role="navigation" aria-labelledby="block-topmenu-2-menu" id="block-topmenu-2">
                              <h2 id="block-topmenu-2-menu">മറ്റുള്ളവ</h2>
                              <ul>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/imageGallery" data-drupal-link-system-path="imageGallery">Gallery</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/rti" data-drupal-link-system-path="node/133">RTI</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/rts" data-drupal-link-system-path="node/134">RTS</a>
                                 </li>
                                 <li>
                                    <a href="https://mvd.kerala.gov.in/en/webLinks" data-drupal-link-system-path="webLinks">Web links</a>
                                 </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>