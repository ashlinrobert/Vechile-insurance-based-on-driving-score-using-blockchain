<?php
include('header.php');
?>




<br>
<!--form-->
<div id="latestnews-wrap">
   <div id="news1" class="container row clr">
      <span class = "content">
         <div>
            <div class="views-element-container" id="block-views-block-news-ticker-block-1">
               <div>
                  <div class="js-view-dom-id-3ab4e2572c7a73374477f7fab8f45306cfc9e3d65aebe7a207a2b93f9fdfac11">
                    
                     <div class="skin-default" style="padding:40px;">
							<div class="row g-10">
							  <br>
							  <center>
								 <h1 style="font-size: 30px;color:red; margin-left: 530px;">Driving Scores</h1><br><br>
							  </center>
							  <div class="col-md-10">
								<?php
                            session_start();
                             include("connection.php");
                                $user=$_SESSION['uid'];
                                $sel = "SELECT * FROM `user`";
                                $res=mysqli_query($con,$sel);
                                $i=1;
								while ($row=mysqli_fetch_array($res)) 
                                 {
									
                                ?>
								<a href="score_single.php?id=<?php echo $row['id'] ?>" class="btn btn-primary"><?php echo $row['name'] ?></a>
								
								</tr>
                             <?php 
							 $i++;
							 } ?>
							  
							  </div>
						   </div>
						
						
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </span>
   </div>
</div>








<!-- FOOTER START  --> 
<div id="footer-wrap" >
  <div id="footer" class="container row clr">
    <div id="footer-nav">  
      	    <div>
    <nav role="navigation" aria-labelledby="block-aboutportal-2-menu" id="block-aboutportal-2">
            
  <h2 class="visually-hidden" id="block-aboutportal-2-menu">About Portal</h2>
  

        
              <ul>
              <li>
        <a href="https://mvd.kerala.gov.in/screen-reader-access" title="Screen Reader Access">Screen Reader Access</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/disclaimer" data-drupal-link-system-path="node/80">Disclaimer</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/copy-right-policy" data-drupal-link-system-path="node/81">Copy Right Policy</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/privacy-policy" data-drupal-link-system-path="node/82">Privacy Policy</a>
              </li>
          <li>
        <a href="https://mvd.kerala.gov.in/en/webLinks" data-drupal-link-system-path="webLinks">Weblinks</a>
              </li>
        </ul>
  


  </nav>

  </div>
    
	  	
    </div>
	<div id="footer-text">
	  <div class = "copyrig" style="display: inline-block;">Motor Vehicles Department Copyright &copy; 2023. All Rights Reserved. </div>
	  <div class = "credit" >Designed and Maintained by <a href="http://www.cdit.org/" target="_blank">C-Dit</a></div>
	</div> 
  </div>
</div>
 







  </div>

    
    <script type="application/json" data-drupal-selector="drupal-settings-json">{"path":{"baseUrl":"\/","scriptPath":null,"pathPrefix":"en\/","currentPath":"node","currentPathIsAdmin":false,"isFront":true,"currentLanguage":"en"},"pluralDelimiter":"\u0003","suppressDeprecationErrors":true,"ajaxPageState":{"libraries":"blazy\/column,blazy\/grid,blazy\/load,blazy\/ratio,core\/html5shiv,mvd\/framework,search_api_autocomplete\/search_api_autocomplete,superfish\/superfish,superfish\/superfish_hoverintent,superfish\/superfish_smallscreen,superfish\/superfish_supersubs,superfish\/superfish_supposition,system\/base,views\/views.ajax,views\/views.module,views_slideshow\/jquery_hoverIntent,views_slideshow\/pager_bullets,views_slideshow\/widget_info,views_slideshow_cycle\/jquery_cycle,views_slideshow_cycle\/json2,views_slideshow_cycle\/views_slideshow_cycle","theme":"mvd","theme_token":null},"ajaxTrustedUrl":{"\/en\/search":true},"viewsSlideshowPagerFields":{"block_slider-block_1":{"bottom":{"activatePauseOnHover":null}},"slideshow-block_1":{"bottom":{"activatePauseOnHover":null}}},"viewsSlideshowPager":{"block_slider-block_1":{"bottom":{"type":"viewsSlideshowPagerBullets"}},"slideshow-block_1":{"bottom":{"type":"viewsSlideshowPagerBullets"}}},"viewsSlideshowCycle":{"#views_slideshow_cycle_main_block_slider-block_1":{"num_divs":4,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"block_slider-block_1","effect":"fade","transition_advanced":1,"timeout":3000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"fixed_height":1,"items_per_slide":1,"items_per_slide_first":0,"items_per_slide_first_number":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"},"#views_slideshow_cycle_main_news_ticker-block_1":{"num_divs":5,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"news_ticker-block_1","effect":"scrollLeft","transition_advanced":1,"timeout":5000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"fixed_height":1,"items_per_slide":1,"items_per_slide_first":0,"items_per_slide_first_number":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"},"#views_slideshow_cycle_main_slideshow-block_1":{"num_divs":5,"id_prefix":"#views_slideshow_cycle_main_","div_prefix":"#views_slideshow_cycle_div_","vss_id":"slideshow-block_1","effect":"fade","transition_advanced":1,"timeout":2000,"speed":700,"delay":0,"sync":1,"random":0,"pause":1,"pause_on_click":0,"action_advanced":0,"start_paused":0,"remember_slide":0,"remember_slide_days":1,"pause_in_middle":0,"pause_when_hidden":0,"pause_when_hidden_type":"full","amount_allowed_visible":"","nowrap":0,"fixed_height":1,"items_per_slide":1,"items_per_slide_first":0,"items_per_slide_first_number":1,"wait_for_image_load":1,"wait_for_image_load_timeout":3000,"cleartype":0,"cleartypenobg":0,"advanced_options":"{}"}},"viewsSlideshow":{"block_slider-block_1":{"methods":{"goToSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowSlideCounter","viewsSlideshowPager"],"transitionEnd":[]},"paused":0},"news_ticker-block_1":{"methods":{"goToSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowSlideCounter","viewsSlideshowPager"],"transitionEnd":[]},"paused":0},"slideshow-block_1":{"methods":{"goToSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"nextSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"pause":["viewsSlideshowControls","viewsSlideshowCycle"],"play":["viewsSlideshowControls","viewsSlideshowCycle"],"previousSlide":["viewsSlideshowSlideCounter","viewsSlideshowPager","viewsSlideshowCycle"],"transitionBegin":["viewsSlideshowSlideCounter","viewsSlideshowPager"],"transitionEnd":[]},"paused":0}},"views":{"ajax_path":"\/index.php\/en\/views\/ajax","ajaxViews":{"views_dom_id:3ab4e2572c7a73374477f7fab8f45306cfc9e3d65aebe7a207a2b93f9fdfac11":{"view_name":"news_ticker","view_display_id":"block_1","view_args":"","view_path":"\/node","view_base_path":"old-news","view_dom_id":"3ab4e2572c7a73374477f7fab8f45306cfc9e3d65aebe7a207a2b93f9fdfac11","pager_element":0}}},"superfish":{"superfish-main":{"id":"superfish-main","sf":{"animation":{"opacity":"show","height":"show"},"speed":"fast"},"plugins":{"smallscreen":{"mode":"window_width","title":"Main navigation"},"supposition":true,"supersubs":true}}},"search_api_autocomplete":{"search_content":{"auto_submit":true}},"blazy":{"loadInvisible":false,"offset":100,"saveViewportOffsetDelay":50,"validateDelay":25},"blazyIo":{"enabled":false,"disconnect":false,"rootMargin":"0px","threshold":[0]},"user":{"uid":0,"permissionsHash":"bb13c26e2f55382c4a634f2cc0f691b351815f736efd9d1101edb3beead98a48"}}</script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery/jquery.min.js?v=3.4.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery-once/jquery.once.min.js?v=2.2.0"></script>
<script src="https://mvd.kerala.gov.in/core/misc/drupalSettingsLoader.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/misc/drupal.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/misc/drupal.init.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/data-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/disable-selection-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/form-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/labels-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/jquery-1-7-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/scroll-parent-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/tabbable-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/unique-id-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/version-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/escape-selector-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/focusable-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/ie-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/keycode-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/plugin-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/safe-active-element-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/safe-blur-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/widget-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/blazy/js/dblazy.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/blazy/js/blazy.load.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/core/misc/autocomplete.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/themes/mvd/js/custom.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/js/views_slideshow.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/libraries/json2/json2.js?v=2"></script>
<script src="https://mvd.kerala.gov.in/libraries/jquery.cycle/jquery.cycle.all.js?v=3.0.3"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/views_slideshow/modules/views_slideshow_cycle/js/views_slideshow_cycle.js?rr8q49"></script>
<script src="https://mvd.kerala.gov.in/libraries/jquery.hoverIntent/jquery.hoverIntent.js?v=1.9"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery-form/jquery.form.min.js?v=4.22"></script>
<script src="https://mvd.kerala.gov.in/core/misc/progress.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/misc/ajax.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/themes/stable/js/ajax.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/modules/views/js/base.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/modules/views/js/ajax_view.js?v=8.8.3"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/position-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/widgets/menu-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/core/assets/vendor/jquery.ui/ui/widgets/autocomplete-min.js?v=1.12.1"></script>
<script src="https://mvd.kerala.gov.in/modules/contrib/search_api_autocomplete/js/search_api_autocomplete.js?rr8q49"></script>

				
				
				<script type="text/javascript">
var _userway_config = {
/* uncomment the following line to override default position*/
/* position: '1', */
/* uncomment the following line to override default size (values: small, large)*/
/* size: 'small', */
/* uncomment the following line to override default language (e.g., fr, de, es, he, nl, etc.)*/
/* language: 'en-US', */
/* uncomment the following line to override color set via widget (e.g., #053f67)*/
/* color: '#053f67', */
/* uncomment the following line to override type set via widget(1=person, 2=chair, 3=eye)*/
/* type: '2', */
/* uncomment the following line to override support on mobile devices*/
/* mobile: true, */
account: 'wFuknyxNOi'
};
</script>
<script type="text/javascript" src="https://cdn.userway.org/widget.js"></script>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-V53G52QEPJ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-V53G52QEPJ');
</script>

  </body>

<!-- Mirrored from mvd.kerala.gov.in/en by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 May 2023 06:52:27 GMT -->
</html>
